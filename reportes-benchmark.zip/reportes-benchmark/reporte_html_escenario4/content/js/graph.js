/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 833.0, "minX": 0.0, "maxY": 97612.0, "series": [{"data": [[0.0, 833.0], [0.1, 892.0], [0.2, 965.0], [0.3, 978.0], [0.4, 987.0], [0.5, 992.0], [0.6, 1011.0], [0.7, 1017.0], [0.8, 1027.0], [0.9, 1031.0], [1.0, 1034.0], [1.1, 1039.0], [1.2, 1044.0], [1.3, 1047.0], [1.4, 1050.0], [1.5, 1052.0], [1.6, 1056.0], [1.7, 1061.0], [1.8, 1063.0], [1.9, 1066.0], [2.0, 1069.0], [2.1, 1074.0], [2.2, 1076.0], [2.3, 1081.0], [2.4, 1084.0], [2.5, 1086.0], [2.6, 1091.0], [2.7, 1096.0], [2.8, 1101.0], [2.9, 1102.0], [3.0, 1106.0], [3.1, 1108.0], [3.2, 1110.0], [3.3, 1112.0], [3.4, 1115.0], [3.5, 1118.0], [3.6, 1119.0], [3.7, 1122.0], [3.8, 1124.0], [3.9, 1126.0], [4.0, 1130.0], [4.1, 1133.0], [4.2, 1135.0], [4.3, 1138.0], [4.4, 1141.0], [4.5, 1143.0], [4.6, 1146.0], [4.7, 1148.0], [4.8, 1149.0], [4.9, 1151.0], [5.0, 1156.0], [5.1, 1158.0], [5.2, 1161.0], [5.3, 1165.0], [5.4, 1168.0], [5.5, 1170.0], [5.6, 1173.0], [5.7, 1177.0], [5.8, 1179.0], [5.9, 1182.0], [6.0, 1182.0], [6.1, 1186.0], [6.2, 1188.0], [6.3, 1193.0], [6.4, 1195.0], [6.5, 1197.0], [6.6, 1198.0], [6.7, 1199.0], [6.8, 1201.0], [6.9, 1203.0], [7.0, 1206.0], [7.1, 1206.0], [7.2, 1207.0], [7.3, 1209.0], [7.4, 1211.0], [7.5, 1212.0], [7.6, 1215.0], [7.7, 1219.0], [7.8, 1220.0], [7.9, 1221.0], [8.0, 1223.0], [8.1, 1225.0], [8.2, 1228.0], [8.3, 1229.0], [8.4, 1231.0], [8.5, 1235.0], [8.6, 1238.0], [8.7, 1240.0], [8.8, 1242.0], [8.9, 1244.0], [9.0, 1245.0], [9.1, 1246.0], [9.2, 1249.0], [9.3, 1250.0], [9.4, 1252.0], [9.5, 1254.0], [9.6, 1257.0], [9.7, 1259.0], [9.8, 1262.0], [9.9, 1264.0], [10.0, 1266.0], [10.1, 1267.0], [10.2, 1269.0], [10.3, 1270.0], [10.4, 1271.0], [10.5, 1272.0], [10.6, 1273.0], [10.7, 1274.0], [10.8, 1277.0], [10.9, 1279.0], [11.0, 1281.0], [11.1, 1281.0], [11.2, 1284.0], [11.3, 1285.0], [11.4, 1287.0], [11.5, 1288.0], [11.6, 1290.0], [11.7, 1291.0], [11.8, 1292.0], [11.9, 1293.0], [12.0, 1295.0], [12.1, 1296.0], [12.2, 1298.0], [12.3, 1299.0], [12.4, 1300.0], [12.5, 1302.0], [12.6, 1302.0], [12.7, 1304.0], [12.8, 1305.0], [12.9, 1307.0], [13.0, 1308.0], [13.1, 1309.0], [13.2, 1310.0], [13.3, 1311.0], [13.4, 1312.0], [13.5, 1313.0], [13.6, 1314.0], [13.7, 1316.0], [13.8, 1317.0], [13.9, 1319.0], [14.0, 1319.0], [14.1, 1320.0], [14.2, 1321.0], [14.3, 1322.0], [14.4, 1323.0], [14.5, 1324.0], [14.6, 1325.0], [14.7, 1326.0], [14.8, 1327.0], [14.9, 1328.0], [15.0, 1329.0], [15.1, 1330.0], [15.2, 1331.0], [15.3, 1331.0], [15.4, 1332.0], [15.5, 1333.0], [15.6, 1334.0], [15.7, 1335.0], [15.8, 1336.0], [15.9, 1337.0], [16.0, 1337.0], [16.1, 1338.0], [16.2, 1339.0], [16.3, 1340.0], [16.4, 1341.0], [16.5, 1342.0], [16.6, 1343.0], [16.7, 1344.0], [16.8, 1345.0], [16.9, 1345.0], [17.0, 1346.0], [17.1, 1347.0], [17.2, 1348.0], [17.3, 1349.0], [17.4, 1350.0], [17.5, 1352.0], [17.6, 1352.0], [17.7, 1353.0], [17.8, 1354.0], [17.9, 1355.0], [18.0, 1356.0], [18.1, 1357.0], [18.2, 1357.0], [18.3, 1358.0], [18.4, 1359.0], [18.5, 1359.0], [18.6, 1360.0], [18.7, 1361.0], [18.8, 1362.0], [18.9, 1362.0], [19.0, 1363.0], [19.1, 1364.0], [19.2, 1365.0], [19.3, 1366.0], [19.4, 1366.0], [19.5, 1367.0], [19.6, 1368.0], [19.7, 1369.0], [19.8, 1370.0], [19.9, 1370.0], [20.0, 1372.0], [20.1, 1372.0], [20.2, 1373.0], [20.3, 1374.0], [20.4, 1374.0], [20.5, 1375.0], [20.6, 1375.0], [20.7, 1376.0], [20.8, 1377.0], [20.9, 1378.0], [21.0, 1379.0], [21.1, 1379.0], [21.2, 1380.0], [21.3, 1381.0], [21.4, 1382.0], [21.5, 1382.0], [21.6, 1383.0], [21.7, 1384.0], [21.8, 1384.0], [21.9, 1385.0], [22.0, 1386.0], [22.1, 1386.0], [22.2, 1387.0], [22.3, 1387.0], [22.4, 1388.0], [22.5, 1389.0], [22.6, 1389.0], [22.7, 1391.0], [22.8, 1391.0], [22.9, 1392.0], [23.0, 1393.0], [23.1, 1394.0], [23.2, 1394.0], [23.3, 1395.0], [23.4, 1396.0], [23.5, 1397.0], [23.6, 1397.0], [23.7, 1398.0], [23.8, 1398.0], [23.9, 1399.0], [24.0, 1400.0], [24.1, 1401.0], [24.2, 1402.0], [24.3, 1402.0], [24.4, 1403.0], [24.5, 1403.0], [24.6, 1404.0], [24.7, 1405.0], [24.8, 1405.0], [24.9, 1406.0], [25.0, 1406.0], [25.1, 1407.0], [25.2, 1408.0], [25.3, 1408.0], [25.4, 1409.0], [25.5, 1409.0], [25.6, 1410.0], [25.7, 1411.0], [25.8, 1411.0], [25.9, 1412.0], [26.0, 1412.0], [26.1, 1413.0], [26.2, 1414.0], [26.3, 1415.0], [26.4, 1415.0], [26.5, 1416.0], [26.6, 1416.0], [26.7, 1417.0], [26.8, 1417.0], [26.9, 1418.0], [27.0, 1418.0], [27.1, 1419.0], [27.2, 1420.0], [27.3, 1421.0], [27.4, 1421.0], [27.5, 1422.0], [27.6, 1423.0], [27.7, 1423.0], [27.8, 1424.0], [27.9, 1425.0], [28.0, 1426.0], [28.1, 1426.0], [28.2, 1427.0], [28.3, 1427.0], [28.4, 1428.0], [28.5, 1428.0], [28.6, 1429.0], [28.7, 1430.0], [28.8, 1430.0], [28.9, 1431.0], [29.0, 1433.0], [29.1, 1433.0], [29.2, 1434.0], [29.3, 1435.0], [29.4, 1435.0], [29.5, 1435.0], [29.6, 1436.0], [29.7, 1436.0], [29.8, 1437.0], [29.9, 1437.0], [30.0, 1438.0], [30.1, 1438.0], [30.2, 1439.0], [30.3, 1440.0], [30.4, 1440.0], [30.5, 1441.0], [30.6, 1441.0], [30.7, 1442.0], [30.8, 1442.0], [30.9, 1443.0], [31.0, 1443.0], [31.1, 1444.0], [31.2, 1444.0], [31.3, 1445.0], [31.4, 1445.0], [31.5, 1446.0], [31.6, 1446.0], [31.7, 1447.0], [31.8, 1447.0], [31.9, 1448.0], [32.0, 1448.0], [32.1, 1449.0], [32.2, 1449.0], [32.3, 1450.0], [32.4, 1450.0], [32.5, 1451.0], [32.6, 1451.0], [32.7, 1452.0], [32.8, 1452.0], [32.9, 1453.0], [33.0, 1454.0], [33.1, 1455.0], [33.2, 1456.0], [33.3, 1456.0], [33.4, 1457.0], [33.5, 1458.0], [33.6, 1458.0], [33.7, 1459.0], [33.8, 1460.0], [33.9, 1461.0], [34.0, 1461.0], [34.1, 1462.0], [34.2, 1463.0], [34.3, 1463.0], [34.4, 1464.0], [34.5, 1464.0], [34.6, 1465.0], [34.7, 1466.0], [34.8, 1466.0], [34.9, 1467.0], [35.0, 1468.0], [35.1, 1469.0], [35.2, 1470.0], [35.3, 1470.0], [35.4, 1471.0], [35.5, 1471.0], [35.6, 1472.0], [35.7, 1473.0], [35.8, 1473.0], [35.9, 1474.0], [36.0, 1474.0], [36.1, 1475.0], [36.2, 1476.0], [36.3, 1476.0], [36.4, 1477.0], [36.5, 1477.0], [36.6, 1478.0], [36.7, 1479.0], [36.8, 1479.0], [36.9, 1480.0], [37.0, 1481.0], [37.1, 1481.0], [37.2, 1482.0], [37.3, 1482.0], [37.4, 1483.0], [37.5, 1484.0], [37.6, 1484.0], [37.7, 1485.0], [37.8, 1486.0], [37.9, 1487.0], [38.0, 1488.0], [38.1, 1489.0], [38.2, 1489.0], [38.3, 1490.0], [38.4, 1491.0], [38.5, 1492.0], [38.6, 1492.0], [38.7, 1493.0], [38.8, 1494.0], [38.9, 1494.0], [39.0, 1495.0], [39.1, 1495.0], [39.2, 1496.0], [39.3, 1496.0], [39.4, 1497.0], [39.5, 1497.0], [39.6, 1498.0], [39.7, 1499.0], [39.8, 1500.0], [39.9, 1501.0], [40.0, 1501.0], [40.1, 1502.0], [40.2, 1503.0], [40.3, 1503.0], [40.4, 1504.0], [40.5, 1504.0], [40.6, 1505.0], [40.7, 1505.0], [40.8, 1506.0], [40.9, 1507.0], [41.0, 1508.0], [41.1, 1508.0], [41.2, 1509.0], [41.3, 1510.0], [41.4, 1511.0], [41.5, 1511.0], [41.6, 1512.0], [41.7, 1513.0], [41.8, 1514.0], [41.9, 1514.0], [42.0, 1514.0], [42.1, 1515.0], [42.2, 1516.0], [42.3, 1517.0], [42.4, 1517.0], [42.5, 1518.0], [42.6, 1519.0], [42.7, 1519.0], [42.8, 1520.0], [42.9, 1521.0], [43.0, 1521.0], [43.1, 1522.0], [43.2, 1523.0], [43.3, 1524.0], [43.4, 1524.0], [43.5, 1525.0], [43.6, 1526.0], [43.7, 1527.0], [43.8, 1528.0], [43.9, 1529.0], [44.0, 1530.0], [44.1, 1531.0], [44.2, 1531.0], [44.3, 1532.0], [44.4, 1533.0], [44.5, 1534.0], [44.6, 1534.0], [44.7, 1535.0], [44.8, 1536.0], [44.9, 1537.0], [45.0, 1538.0], [45.1, 1540.0], [45.2, 1540.0], [45.3, 1541.0], [45.4, 1542.0], [45.5, 1543.0], [45.6, 1544.0], [45.7, 1545.0], [45.8, 1546.0], [45.9, 1546.0], [46.0, 1547.0], [46.1, 1548.0], [46.2, 1548.0], [46.3, 1549.0], [46.4, 1550.0], [46.5, 1550.0], [46.6, 1551.0], [46.7, 1552.0], [46.8, 1553.0], [46.9, 1554.0], [47.0, 1555.0], [47.1, 1556.0], [47.2, 1557.0], [47.3, 1558.0], [47.4, 1558.0], [47.5, 1559.0], [47.6, 1560.0], [47.7, 1561.0], [47.8, 1561.0], [47.9, 1562.0], [48.0, 1563.0], [48.1, 1564.0], [48.2, 1565.0], [48.3, 1565.0], [48.4, 1566.0], [48.5, 1567.0], [48.6, 1568.0], [48.7, 1568.0], [48.8, 1569.0], [48.9, 1570.0], [49.0, 1571.0], [49.1, 1572.0], [49.2, 1572.0], [49.3, 1573.0], [49.4, 1573.0], [49.5, 1574.0], [49.6, 1575.0], [49.7, 1576.0], [49.8, 1577.0], [49.9, 1577.0], [50.0, 1578.0], [50.1, 1579.0], [50.2, 1579.0], [50.3, 1580.0], [50.4, 1581.0], [50.5, 1581.0], [50.6, 1582.0], [50.7, 1582.0], [50.8, 1583.0], [50.9, 1583.0], [51.0, 1584.0], [51.1, 1584.0], [51.2, 1585.0], [51.3, 1586.0], [51.4, 1586.0], [51.5, 1588.0], [51.6, 1588.0], [51.7, 1589.0], [51.8, 1590.0], [51.9, 1590.0], [52.0, 1592.0], [52.1, 1593.0], [52.2, 1594.0], [52.3, 1594.0], [52.4, 1595.0], [52.5, 1596.0], [52.6, 1597.0], [52.7, 1597.0], [52.8, 1598.0], [52.9, 1599.0], [53.0, 1599.0], [53.1, 1600.0], [53.2, 1601.0], [53.3, 1601.0], [53.4, 1602.0], [53.5, 1602.0], [53.6, 1603.0], [53.7, 1604.0], [53.8, 1604.0], [53.9, 1605.0], [54.0, 1606.0], [54.1, 1607.0], [54.2, 1607.0], [54.3, 1608.0], [54.4, 1609.0], [54.5, 1609.0], [54.6, 1610.0], [54.7, 1611.0], [54.8, 1612.0], [54.9, 1613.0], [55.0, 1613.0], [55.1, 1614.0], [55.2, 1615.0], [55.3, 1616.0], [55.4, 1616.0], [55.5, 1617.0], [55.6, 1618.0], [55.7, 1618.0], [55.8, 1619.0], [55.9, 1619.0], [56.0, 1620.0], [56.1, 1621.0], [56.2, 1622.0], [56.3, 1623.0], [56.4, 1623.0], [56.5, 1624.0], [56.6, 1625.0], [56.7, 1626.0], [56.8, 1627.0], [56.9, 1628.0], [57.0, 1628.0], [57.1, 1629.0], [57.2, 1630.0], [57.3, 1631.0], [57.4, 1632.0], [57.5, 1632.0], [57.6, 1633.0], [57.7, 1634.0], [57.8, 1635.0], [57.9, 1635.0], [58.0, 1637.0], [58.1, 1638.0], [58.2, 1638.0], [58.3, 1639.0], [58.4, 1640.0], [58.5, 1641.0], [58.6, 1642.0], [58.7, 1643.0], [58.8, 1644.0], [58.9, 1645.0], [59.0, 1647.0], [59.1, 1648.0], [59.2, 1649.0], [59.3, 1650.0], [59.4, 1651.0], [59.5, 1652.0], [59.6, 1653.0], [59.7, 1655.0], [59.8, 1656.0], [59.9, 1657.0], [60.0, 1657.0], [60.1, 1658.0], [60.2, 1659.0], [60.3, 1660.0], [60.4, 1660.0], [60.5, 1661.0], [60.6, 1662.0], [60.7, 1662.0], [60.8, 1664.0], [60.9, 1664.0], [61.0, 1665.0], [61.1, 1666.0], [61.2, 1667.0], [61.3, 1668.0], [61.4, 1670.0], [61.5, 1671.0], [61.6, 1672.0], [61.7, 1673.0], [61.8, 1675.0], [61.9, 1676.0], [62.0, 1677.0], [62.1, 1678.0], [62.2, 1679.0], [62.3, 1680.0], [62.4, 1681.0], [62.5, 1682.0], [62.6, 1682.0], [62.7, 1683.0], [62.8, 1685.0], [62.9, 1686.0], [63.0, 1687.0], [63.1, 1688.0], [63.2, 1690.0], [63.3, 1691.0], [63.4, 1691.0], [63.5, 1692.0], [63.6, 1693.0], [63.7, 1694.0], [63.8, 1695.0], [63.9, 1696.0], [64.0, 1697.0], [64.1, 1698.0], [64.2, 1699.0], [64.3, 1699.0], [64.4, 1700.0], [64.5, 1701.0], [64.6, 1702.0], [64.7, 1702.0], [64.8, 1704.0], [64.9, 1705.0], [65.0, 1705.0], [65.1, 1706.0], [65.2, 1707.0], [65.3, 1708.0], [65.4, 1709.0], [65.5, 1710.0], [65.6, 1711.0], [65.7, 1712.0], [65.8, 1713.0], [65.9, 1714.0], [66.0, 1715.0], [66.1, 1716.0], [66.2, 1717.0], [66.3, 1719.0], [66.4, 1720.0], [66.5, 1721.0], [66.6, 1722.0], [66.7, 1723.0], [66.8, 1724.0], [66.9, 1725.0], [67.0, 1726.0], [67.1, 1727.0], [67.2, 1728.0], [67.3, 1730.0], [67.4, 1730.0], [67.5, 1731.0], [67.6, 1732.0], [67.7, 1732.0], [67.8, 1733.0], [67.9, 1734.0], [68.0, 1735.0], [68.1, 1736.0], [68.2, 1737.0], [68.3, 1737.0], [68.4, 1739.0], [68.5, 1739.0], [68.6, 1740.0], [68.7, 1741.0], [68.8, 1742.0], [68.9, 1743.0], [69.0, 1743.0], [69.1, 1744.0], [69.2, 1745.0], [69.3, 1746.0], [69.4, 1747.0], [69.5, 1748.0], [69.6, 1749.0], [69.7, 1750.0], [69.8, 1751.0], [69.9, 1752.0], [70.0, 1753.0], [70.1, 1753.0], [70.2, 1754.0], [70.3, 1755.0], [70.4, 1756.0], [70.5, 1757.0], [70.6, 1758.0], [70.7, 1758.0], [70.8, 1759.0], [70.9, 1759.0], [71.0, 1760.0], [71.1, 1761.0], [71.2, 1763.0], [71.3, 1763.0], [71.4, 1764.0], [71.5, 1765.0], [71.6, 1765.0], [71.7, 1767.0], [71.8, 1768.0], [71.9, 1769.0], [72.0, 1770.0], [72.1, 1772.0], [72.2, 1773.0], [72.3, 1775.0], [72.4, 1777.0], [72.5, 1777.0], [72.6, 1779.0], [72.7, 1781.0], [72.8, 1783.0], [72.9, 1784.0], [73.0, 1785.0], [73.1, 1786.0], [73.2, 1787.0], [73.3, 1788.0], [73.4, 1790.0], [73.5, 1792.0], [73.6, 1793.0], [73.7, 1793.0], [73.8, 1795.0], [73.9, 1796.0], [74.0, 1798.0], [74.1, 1799.0], [74.2, 1800.0], [74.3, 1801.0], [74.4, 1803.0], [74.5, 1804.0], [74.6, 1805.0], [74.7, 1807.0], [74.8, 1809.0], [74.9, 1810.0], [75.0, 1812.0], [75.1, 1812.0], [75.2, 1814.0], [75.3, 1815.0], [75.4, 1818.0], [75.5, 1821.0], [75.6, 1822.0], [75.7, 1824.0], [75.8, 1825.0], [75.9, 1826.0], [76.0, 1830.0], [76.1, 1832.0], [76.2, 1833.0], [76.3, 1835.0], [76.4, 1837.0], [76.5, 1840.0], [76.6, 1841.0], [76.7, 1842.0], [76.8, 1842.0], [76.9, 1845.0], [77.0, 1846.0], [77.1, 1848.0], [77.2, 1849.0], [77.3, 1850.0], [77.4, 1850.0], [77.5, 1851.0], [77.6, 1853.0], [77.7, 1854.0], [77.8, 1855.0], [77.9, 1856.0], [78.0, 1857.0], [78.1, 1859.0], [78.2, 1861.0], [78.3, 1862.0], [78.4, 1863.0], [78.5, 1865.0], [78.6, 1866.0], [78.7, 1869.0], [78.8, 1870.0], [78.9, 1871.0], [79.0, 1872.0], [79.1, 1874.0], [79.2, 1876.0], [79.3, 1878.0], [79.4, 1879.0], [79.5, 1881.0], [79.6, 1882.0], [79.7, 1883.0], [79.8, 1885.0], [79.9, 1886.0], [80.0, 1887.0], [80.1, 1889.0], [80.2, 1893.0], [80.3, 1894.0], [80.4, 1896.0], [80.5, 1896.0], [80.6, 1898.0], [80.7, 1901.0], [80.8, 1903.0], [80.9, 1904.0], [81.0, 1907.0], [81.1, 1910.0], [81.2, 1911.0], [81.3, 1913.0], [81.4, 1913.0], [81.5, 1915.0], [81.6, 1917.0], [81.7, 1918.0], [81.8, 1921.0], [81.9, 1923.0], [82.0, 1925.0], [82.1, 1926.0], [82.2, 1927.0], [82.3, 1928.0], [82.4, 1929.0], [82.5, 1930.0], [82.6, 1934.0], [82.7, 1935.0], [82.8, 1936.0], [82.9, 1938.0], [83.0, 1938.0], [83.1, 1939.0], [83.2, 1942.0], [83.3, 1944.0], [83.4, 1944.0], [83.5, 1946.0], [83.6, 1949.0], [83.7, 1950.0], [83.8, 1953.0], [83.9, 1955.0], [84.0, 1958.0], [84.1, 1960.0], [84.2, 1962.0], [84.3, 1968.0], [84.4, 1972.0], [84.5, 1977.0], [84.6, 1979.0], [84.7, 1984.0], [84.8, 1988.0], [84.9, 1990.0], [85.0, 1994.0], [85.1, 1999.0], [85.2, 2002.0], [85.3, 2005.0], [85.4, 2007.0], [85.5, 2011.0], [85.6, 2015.0], [85.7, 2019.0], [85.8, 2021.0], [85.9, 2024.0], [86.0, 2026.0], [86.1, 2028.0], [86.2, 2031.0], [86.3, 2033.0], [86.4, 2034.0], [86.5, 2038.0], [86.6, 2039.0], [86.7, 2041.0], [86.8, 2043.0], [86.9, 2044.0], [87.0, 2046.0], [87.1, 2048.0], [87.2, 2050.0], [87.3, 2053.0], [87.4, 2055.0], [87.5, 2058.0], [87.6, 2059.0], [87.7, 2064.0], [87.8, 2069.0], [87.9, 2072.0], [88.0, 2074.0], [88.1, 2076.0], [88.2, 2077.0], [88.3, 2079.0], [88.4, 2083.0], [88.5, 2086.0], [88.6, 2088.0], [88.7, 2093.0], [88.8, 2098.0], [88.9, 2102.0], [89.0, 2109.0], [89.1, 2111.0], [89.2, 2120.0], [89.3, 2125.0], [89.4, 2127.0], [89.5, 2129.0], [89.6, 2135.0], [89.7, 2141.0], [89.8, 2142.0], [89.9, 2146.0], [90.0, 2153.0], [90.1, 2162.0], [90.2, 2170.0], [90.3, 2183.0], [90.4, 2187.0], [90.5, 2192.0], [90.6, 2197.0], [90.7, 2200.0], [90.8, 2205.0], [90.9, 2216.0], [91.0, 2232.0], [91.1, 2246.0], [91.2, 2253.0], [91.3, 2266.0], [91.4, 2281.0], [91.5, 2314.0], [91.6, 2343.0], [91.7, 2377.0], [91.8, 2418.0], [91.9, 2428.0], [92.0, 2447.0], [92.1, 2465.0], [92.2, 2498.0], [92.3, 2517.0], [92.4, 2534.0], [92.5, 2557.0], [92.6, 2579.0], [92.7, 2585.0], [92.8, 2594.0], [92.9, 2612.0], [93.0, 2626.0], [93.1, 2653.0], [93.2, 2671.0], [93.3, 2687.0], [93.4, 2700.0], [93.5, 2715.0], [93.6, 2737.0], [93.7, 2749.0], [93.8, 2789.0], [93.9, 2804.0], [94.0, 2818.0], [94.1, 2838.0], [94.2, 2856.0], [94.3, 2887.0], [94.4, 2905.0], [94.5, 2916.0], [94.6, 2930.0], [94.7, 2950.0], [94.8, 2972.0], [94.9, 2991.0], [95.0, 3019.0], [95.1, 3037.0], [95.2, 3070.0], [95.3, 3087.0], [95.4, 3106.0], [95.5, 3123.0], [95.6, 3134.0], [95.7, 3158.0], [95.8, 3207.0], [95.9, 3239.0], [96.0, 3274.0], [96.1, 3311.0], [96.2, 3348.0], [96.3, 3364.0], [96.4, 3404.0], [96.5, 3436.0], [96.6, 3525.0], [96.7, 3570.0], [96.8, 3633.0], [96.9, 3710.0], [97.0, 3777.0], [97.1, 3822.0], [97.2, 3848.0], [97.3, 3887.0], [97.4, 3947.0], [97.5, 4034.0], [97.6, 4112.0], [97.7, 4182.0], [97.8, 4281.0], [97.9, 4346.0], [98.0, 4423.0], [98.1, 4474.0], [98.2, 4582.0], [98.3, 4663.0], [98.4, 5113.0], [98.5, 5401.0], [98.6, 5632.0], [98.7, 6010.0], [98.8, 6103.0], [98.9, 6301.0], [99.0, 6408.0], [99.1, 6823.0], [99.2, 7224.0], [99.3, 8549.0], [99.4, 10662.0], [99.5, 12235.0], [99.6, 14050.0], [99.7, 20161.0], [99.8, 28499.0], [99.9, 33955.0], [100.0, 97612.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 800.0, "maxY": 1033.0, "series": [{"data": [[33700.0, 1.0], [33900.0, 2.0], [37500.0, 1.0], [38100.0, 1.0], [42900.0, 1.0], [63100.0, 1.0], [800.0, 7.0], [900.0, 29.0], [1000.0, 144.0], [1100.0, 259.0], [1200.0, 367.0], [1300.0, 760.0], [1400.0, 1033.0], [1500.0, 873.0], [1600.0, 736.0], [1700.0, 645.0], [1800.0, 425.0], [1900.0, 292.0], [2000.0, 243.0], [2100.0, 122.0], [2300.0, 20.0], [2200.0, 49.0], [2400.0, 30.0], [2500.0, 40.0], [2600.0, 38.0], [2700.0, 31.0], [2800.0, 32.0], [2900.0, 38.0], [3000.0, 26.0], [3100.0, 28.0], [3200.0, 21.0], [3300.0, 19.0], [3400.0, 13.0], [3500.0, 12.0], [3600.0, 8.0], [3700.0, 10.0], [3800.0, 19.0], [3900.0, 10.0], [4000.0, 5.0], [4100.0, 12.0], [4200.0, 5.0], [4300.0, 10.0], [4400.0, 11.0], [4500.0, 7.0], [4600.0, 4.0], [4800.0, 3.0], [4700.0, 1.0], [5000.0, 1.0], [4900.0, 1.0], [5100.0, 1.0], [5200.0, 3.0], [5300.0, 2.0], [5400.0, 4.0], [5500.0, 2.0], [5600.0, 2.0], [5800.0, 2.0], [5700.0, 2.0], [6000.0, 7.0], [5900.0, 1.0], [6100.0, 4.0], [6300.0, 6.0], [6200.0, 3.0], [6400.0, 6.0], [6500.0, 1.0], [6800.0, 1.0], [6900.0, 2.0], [7000.0, 2.0], [7100.0, 1.0], [7300.0, 1.0], [7200.0, 1.0], [7600.0, 1.0], [7900.0, 1.0], [8500.0, 1.0], [8600.0, 1.0], [8300.0, 1.0], [8400.0, 1.0], [8700.0, 1.0], [8200.0, 1.0], [8800.0, 1.0], [9000.0, 1.0], [9700.0, 1.0], [10600.0, 1.0], [11100.0, 1.0], [11300.0, 2.0], [12100.0, 1.0], [12200.0, 2.0], [11900.0, 2.0], [12300.0, 1.0], [12700.0, 1.0], [12900.0, 2.0], [14300.0, 1.0], [14000.0, 1.0], [15600.0, 1.0], [16100.0, 1.0], [18600.0, 1.0], [19100.0, 1.0], [19500.0, 1.0], [20100.0, 1.0], [21000.0, 1.0], [23100.0, 1.0], [25300.0, 1.0], [26500.0, 1.0], [27400.0, 1.0], [28400.0, 1.0], [29100.0, 1.0], [29000.0, 1.0], [29400.0, 1.0], [33200.0, 1.0], [36200.0, 1.0], [97600.0, 1.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 97600.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 2609.0, "minX": 1.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 3935.0, "series": [{"data": [], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 2609.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 3935.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 98.12307692307694, "minX": 1.78131588E12, "maxY": 199.99700740274056, "series": [{"data": [[1.78131588E12, 199.99700740274056], [1.78131594E12, 98.12307692307694]], "isOverall": false, "label": "setUp Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.78131594E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 1211.0, "minX": 1.0, "maxY": 97612.0, "series": [{"data": [[2.0, 36277.0], [3.0, 33955.0], [4.0, 63121.0], [5.0, 19187.0], [6.0, 14050.0], [7.0, 23126.0], [8.0, 20161.0], [10.0, 37864.5], [11.0, 19544.0], [12.0, 11924.0], [13.0, 18620.0], [14.0, 33270.0], [15.0, 7990.0], [16.0, 7614.0], [17.0, 5216.0], [18.0, 11308.0], [19.0, 12265.0], [20.0, 1832.0], [22.0, 1413.5], [24.0, 1410.0], [25.0, 1418.0], [27.0, 1432.0], [29.0, 1437.5], [30.0, 1433.0], [31.0, 1429.0], [33.0, 1427.0], [32.0, 1568.0], [35.0, 1437.0], [34.0, 1447.0], [37.0, 1428.0], [36.0, 1435.0], [39.0, 1436.0], [38.0, 2809.0], [41.0, 1407.0], [40.0, 1410.0], [43.0, 1450.0], [45.0, 1447.0], [47.0, 1474.0], [46.0, 1387.0], [49.0, 1626.0], [48.0, 1423.0], [51.0, 1496.0], [50.0, 1437.0], [53.0, 1551.0], [52.0, 1522.0], [54.0, 1424.0], [57.0, 1444.0], [56.0, 1416.5], [59.0, 1484.5], [61.0, 1495.0], [60.0, 1440.0], [63.0, 1506.0], [62.0, 1580.0], [67.0, 1506.0], [66.0, 1515.5], [64.0, 1515.0], [71.0, 1444.0], [70.0, 1419.0], [69.0, 1476.0], [68.0, 1436.0], [75.0, 1429.0], [74.0, 1421.0], [73.0, 1430.0], [72.0, 1423.0], [79.0, 1379.5], [77.0, 1405.0], [76.0, 2791.0], [82.0, 1375.0], [81.0, 1377.0], [80.0, 1393.0], [87.0, 1343.0], [86.0, 1300.0], [85.0, 1319.0], [84.0, 1413.5], [91.0, 1403.0], [90.0, 1301.0], [89.0, 1301.0], [88.0, 1313.0], [95.0, 1262.0], [94.0, 1268.0], [93.0, 1264.0], [92.0, 1271.0], [99.0, 1255.0], [97.0, 1252.0], [96.0, 25338.0], [103.0, 1258.0], [102.0, 1267.5], [100.0, 1285.0], [107.0, 1274.0], [106.0, 1298.0], [105.0, 1266.0], [104.0, 1251.0], [111.0, 1287.0], [110.0, 1288.0], [109.0, 1251.0], [108.0, 1285.0], [115.0, 1268.0], [114.0, 1261.0], [113.0, 1395.0], [119.0, 1243.0], [118.0, 1240.0], [117.0, 1257.5], [123.0, 1214.0], [122.0, 1226.0], [121.0, 1228.0], [120.0, 1230.0], [127.0, 1375.0], [126.0, 1384.0], [125.0, 1531.0], [124.0, 1211.0], [135.0, 1420.0], [134.0, 1438.0], [133.0, 1433.0], [131.0, 5214.0], [130.0, 1388.0], [129.0, 1377.0], [128.0, 1344.0], [143.0, 2804.0], [142.0, 1492.0], [141.0, 1486.0], [140.0, 1443.0], [139.0, 1500.0], [137.0, 1418.0], [136.0, 1416.0], [151.0, 1510.0], [150.0, 1583.0], [149.0, 1454.0], [148.0, 1483.5], [146.0, 1519.0], [145.0, 1633.0], [144.0, 1487.0], [159.0, 1609.0], [158.0, 1476.0], [157.0, 1606.0], [155.0, 1572.0], [153.0, 1556.0], [152.0, 1471.0], [167.0, 1517.0], [166.0, 1435.0], [165.0, 1573.0], [164.0, 1527.0], [163.0, 1532.0], [162.0, 1561.0], [161.0, 2135.0], [160.0, 1616.0], [175.0, 1523.0], [174.0, 1444.0], [173.0, 1538.0], [172.0, 1548.0], [171.0, 1517.0], [170.0, 1528.0], [169.0, 1549.0], [168.0, 1533.0], [182.0, 2704.0], [181.0, 1514.0], [180.0, 1515.0], [179.0, 1518.0], [178.0, 1513.0], [177.0, 1528.0], [176.0, 1534.0], [190.0, 1604.0], [189.0, 1583.0], [188.0, 1956.0], [187.0, 1580.0], [186.0, 1592.0], [185.0, 2575.0], [184.0, 1900.0], [199.0, 1573.333333333333], [198.0, 3408.0], [196.0, 1588.0], [195.0, 1574.0], [194.0, 1594.0], [192.0, 1597.5], [200.0, 1799.8940972222233], [1.0, 97612.0]], "isOverall": false, "label": "HTTP Request", "isController": false}, {"data": [[196.96133863080672, 1868.8791259168715]], "isOverall": false, "label": "HTTP Request-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 200.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 380.25, "minX": 1.78131588E12, "maxY": 2954007.9166666665, "series": [{"data": [[1.78131588E12, 2954007.9166666665], [1.78131594E12, 93839.28333333334]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.78131588E12, 12380.55], [1.78131594E12, 380.25]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.78131594E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 1800.2994172310614, "minX": 1.78131588E12, "maxY": 4101.764102564103, "series": [{"data": [[1.78131588E12, 1800.2994172310614], [1.78131594E12, 4101.764102564103]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.78131594E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 1718.6263978579298, "minX": 1.78131588E12, "maxY": 2820.5435897435896, "series": [{"data": [[1.78131588E12, 1718.6263978579298], [1.78131594E12, 2820.5435897435896]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.78131594E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.78131588E12, "maxY": 73.8061111986142, "series": [{"data": [[1.78131588E12, 73.8061111986142], [1.78131594E12, 0.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.78131594E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 833.0, "minX": 1.78131588E12, "maxY": 97612.0, "series": [{"data": [[1.78131588E12, 42907.0], [1.78131594E12, 97612.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.78131588E12, 833.0], [1.78131594E12, 1211.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.78131588E12, 2145.0], [1.78131594E12, 6175.2000000000135]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.78131588E12, 6062.5], [1.78131594E12, 64500.63999999972]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.78131588E12, 1583.0], [1.78131594E12, 1454.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.78131588E12, 2981.5], [1.78131594E12, 20753.999999999967]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.78131594E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 1171.0, "minX": 1.0, "maxY": 20161.0, "series": [{"data": [[2.0, 18588.0], [50.0, 1656.0], [51.0, 1444.0], [63.0, 1445.0], [65.0, 1675.0], [74.0, 1571.5], [79.0, 1862.0], [81.0, 1444.0], [5.0, 20161.0], [86.0, 1739.5], [89.0, 1826.5], [91.0, 1729.5], [97.0, 2995.0], [98.0, 1794.5], [100.0, 1925.0], [103.0, 1818.0], [106.0, 1451.0], [107.0, 1705.0], [108.0, 1603.5], [110.0, 1616.0], [109.0, 1726.0], [115.0, 1903.0], [113.0, 1412.0], [112.0, 1446.5], [119.0, 1883.0], [117.0, 1398.0], [118.0, 1839.0], [121.0, 1447.0], [123.0, 1836.0], [120.0, 1388.0], [125.0, 3813.0], [127.0, 1462.0], [126.0, 1443.5], [129.0, 1476.0], [132.0, 1515.0], [130.0, 1498.5], [135.0, 1233.0], [128.0, 1171.0], [136.0, 1375.5], [150.0, 1391.0], [146.0, 1539.0], [155.0, 1419.5], [152.0, 1443.0], [160.0, 1336.0], [1.0, 19187.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 160.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 1164.0, "minX": 1.0, "maxY": 20153.0, "series": [{"data": [[2.0, 9706.5], [50.0, 1611.0], [51.0, 1429.0], [63.0, 1426.0], [65.0, 1637.0], [74.0, 1452.0], [79.0, 1837.0], [81.0, 1374.0], [5.0, 20153.0], [86.0, 1719.0], [89.0, 1738.0], [91.0, 1670.5], [97.0, 2975.0], [98.0, 1771.0], [100.0, 1912.5], [103.0, 1788.0], [106.0, 1441.0], [107.0, 1683.0], [108.0, 1592.5], [110.0, 1599.0], [109.0, 1708.0], [115.0, 1895.0], [113.0, 1394.0], [112.0, 1431.0], [119.0, 1822.5], [117.0, 1384.0], [118.0, 1823.0], [121.0, 1421.0], [123.0, 1794.0], [120.0, 1369.5], [125.0, 3747.0], [127.0, 1440.0], [126.0, 1425.0], [129.0, 1436.0], [132.0, 1469.5], [130.0, 1483.5], [135.0, 1222.0], [128.0, 1164.0], [136.0, 1364.0], [150.0, 1354.0], [146.0, 1509.5], [155.0, 1394.0], [152.0, 1426.0], [160.0, 1322.5], [1.0, 7610.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 160.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 109.06666666666666, "minX": 1.78131588E12, "maxY": 109.06666666666666, "series": [{"data": [[1.78131588E12, 109.06666666666666]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.78131588E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 3.25, "minX": 1.78131588E12, "maxY": 105.81666666666666, "series": [{"data": [[1.78131588E12, 105.81666666666666], [1.78131594E12, 3.25]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.78131594E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 3.25, "minX": 1.78131588E12, "maxY": 105.81666666666666, "series": [{"data": [[1.78131588E12, 105.81666666666666], [1.78131594E12, 3.25]], "isOverall": false, "label": "HTTP Request-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.78131594E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 3.25, "minX": 1.78131588E12, "maxY": 105.81666666666666, "series": [{"data": [[1.78131588E12, 105.81666666666666], [1.78131594E12, 3.25]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.78131594E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

