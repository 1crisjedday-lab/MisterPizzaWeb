/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 440.0, "minX": 0.0, "maxY": 195536.0, "series": [{"data": [[0.0, 440.0], [0.1, 442.0], [0.2, 446.0], [0.3, 448.0], [0.4, 457.0], [0.5, 460.0], [0.6, 462.0], [0.7, 467.0], [0.8, 470.0], [0.9, 473.0], [1.0, 487.0], [1.1, 492.0], [1.2, 494.0], [1.3, 495.0], [1.4, 502.0], [1.5, 505.0], [1.6, 507.0], [1.7, 515.0], [1.8, 530.0], [1.9, 537.0], [2.0, 555.0], [2.1, 557.0], [2.2, 561.0], [2.3, 566.0], [2.4, 572.0], [2.5, 579.0], [2.6, 582.0], [2.7, 584.0], [2.8, 586.0], [2.9, 591.0], [3.0, 593.0], [3.1, 594.0], [3.2, 595.0], [3.3, 598.0], [3.4, 602.0], [3.5, 604.0], [3.6, 605.0], [3.7, 606.0], [3.8, 607.0], [3.9, 607.0], [4.0, 611.0], [4.1, 612.0], [4.2, 614.0], [4.3, 614.0], [4.4, 616.0], [4.5, 616.0], [4.6, 618.0], [4.7, 619.0], [4.8, 620.0], [4.9, 622.0], [5.0, 622.0], [5.1, 623.0], [5.2, 624.0], [5.3, 624.0], [5.4, 625.0], [5.5, 625.0], [5.6, 626.0], [5.7, 628.0], [5.8, 631.0], [5.9, 633.0], [6.0, 633.0], [6.1, 635.0], [6.2, 636.0], [6.3, 636.0], [6.4, 637.0], [6.5, 637.0], [6.6, 639.0], [6.7, 639.0], [6.8, 641.0], [6.9, 641.0], [7.0, 643.0], [7.1, 644.0], [7.2, 644.0], [7.3, 644.0], [7.4, 644.0], [7.5, 645.0], [7.6, 646.0], [7.7, 646.0], [7.8, 647.0], [7.9, 647.0], [8.0, 648.0], [8.1, 648.0], [8.2, 649.0], [8.3, 649.0], [8.4, 649.0], [8.5, 651.0], [8.6, 652.0], [8.7, 652.0], [8.8, 652.0], [8.9, 653.0], [9.0, 653.0], [9.1, 653.0], [9.2, 654.0], [9.3, 654.0], [9.4, 654.0], [9.5, 655.0], [9.6, 655.0], [9.7, 656.0], [9.8, 656.0], [9.9, 657.0], [10.0, 658.0], [10.1, 659.0], [10.2, 659.0], [10.3, 660.0], [10.4, 660.0], [10.5, 660.0], [10.6, 661.0], [10.7, 661.0], [10.8, 662.0], [10.9, 662.0], [11.0, 662.0], [11.1, 663.0], [11.2, 663.0], [11.3, 664.0], [11.4, 664.0], [11.5, 665.0], [11.6, 665.0], [11.7, 665.0], [11.8, 666.0], [11.9, 666.0], [12.0, 666.0], [12.1, 666.0], [12.2, 667.0], [12.3, 668.0], [12.4, 668.0], [12.5, 668.0], [12.6, 669.0], [12.7, 669.0], [12.8, 670.0], [12.9, 671.0], [13.0, 671.0], [13.1, 672.0], [13.2, 672.0], [13.3, 672.0], [13.4, 672.0], [13.5, 673.0], [13.6, 673.0], [13.7, 674.0], [13.8, 674.0], [13.9, 675.0], [14.0, 675.0], [14.1, 675.0], [14.2, 675.0], [14.3, 675.0], [14.4, 676.0], [14.5, 676.0], [14.6, 676.0], [14.7, 677.0], [14.8, 677.0], [14.9, 677.0], [15.0, 677.0], [15.1, 678.0], [15.2, 679.0], [15.3, 679.0], [15.4, 679.0], [15.5, 679.0], [15.6, 679.0], [15.7, 680.0], [15.8, 680.0], [15.9, 680.0], [16.0, 681.0], [16.1, 681.0], [16.2, 682.0], [16.3, 682.0], [16.4, 682.0], [16.5, 682.0], [16.6, 683.0], [16.7, 683.0], [16.8, 683.0], [16.9, 683.0], [17.0, 683.0], [17.1, 684.0], [17.2, 684.0], [17.3, 684.0], [17.4, 685.0], [17.5, 685.0], [17.6, 686.0], [17.7, 686.0], [17.8, 687.0], [17.9, 687.0], [18.0, 687.0], [18.1, 688.0], [18.2, 688.0], [18.3, 688.0], [18.4, 688.0], [18.5, 689.0], [18.6, 689.0], [18.7, 690.0], [18.8, 690.0], [18.9, 690.0], [19.0, 690.0], [19.1, 691.0], [19.2, 691.0], [19.3, 691.0], [19.4, 691.0], [19.5, 692.0], [19.6, 692.0], [19.7, 692.0], [19.8, 693.0], [19.9, 693.0], [20.0, 693.0], [20.1, 694.0], [20.2, 694.0], [20.3, 694.0], [20.4, 695.0], [20.5, 695.0], [20.6, 695.0], [20.7, 695.0], [20.8, 695.0], [20.9, 696.0], [21.0, 696.0], [21.1, 696.0], [21.2, 697.0], [21.3, 697.0], [21.4, 697.0], [21.5, 697.0], [21.6, 697.0], [21.7, 698.0], [21.8, 698.0], [21.9, 698.0], [22.0, 699.0], [22.1, 699.0], [22.2, 700.0], [22.3, 700.0], [22.4, 700.0], [22.5, 701.0], [22.6, 701.0], [22.7, 701.0], [22.8, 702.0], [22.9, 702.0], [23.0, 703.0], [23.1, 703.0], [23.2, 703.0], [23.3, 703.0], [23.4, 704.0], [23.5, 704.0], [23.6, 704.0], [23.7, 705.0], [23.8, 705.0], [23.9, 706.0], [24.0, 706.0], [24.1, 706.0], [24.2, 707.0], [24.3, 707.0], [24.4, 708.0], [24.5, 708.0], [24.6, 708.0], [24.7, 708.0], [24.8, 708.0], [24.9, 709.0], [25.0, 709.0], [25.1, 710.0], [25.2, 710.0], [25.3, 710.0], [25.4, 711.0], [25.5, 711.0], [25.6, 711.0], [25.7, 712.0], [25.8, 712.0], [25.9, 713.0], [26.0, 713.0], [26.1, 713.0], [26.2, 713.0], [26.3, 714.0], [26.4, 714.0], [26.5, 714.0], [26.6, 715.0], [26.7, 715.0], [26.8, 715.0], [26.9, 715.0], [27.0, 715.0], [27.1, 715.0], [27.2, 716.0], [27.3, 716.0], [27.4, 716.0], [27.5, 717.0], [27.6, 717.0], [27.7, 717.0], [27.8, 718.0], [27.9, 718.0], [28.0, 718.0], [28.1, 719.0], [28.2, 719.0], [28.3, 720.0], [28.4, 720.0], [28.5, 721.0], [28.6, 721.0], [28.7, 722.0], [28.8, 722.0], [28.9, 723.0], [29.0, 723.0], [29.1, 723.0], [29.2, 723.0], [29.3, 724.0], [29.4, 724.0], [29.5, 725.0], [29.6, 725.0], [29.7, 726.0], [29.8, 726.0], [29.9, 727.0], [30.0, 727.0], [30.1, 727.0], [30.2, 728.0], [30.3, 728.0], [30.4, 729.0], [30.5, 729.0], [30.6, 729.0], [30.7, 729.0], [30.8, 729.0], [30.9, 730.0], [31.0, 730.0], [31.1, 731.0], [31.2, 731.0], [31.3, 731.0], [31.4, 732.0], [31.5, 732.0], [31.6, 732.0], [31.7, 733.0], [31.8, 733.0], [31.9, 734.0], [32.0, 734.0], [32.1, 734.0], [32.2, 735.0], [32.3, 735.0], [32.4, 736.0], [32.5, 736.0], [32.6, 737.0], [32.7, 737.0], [32.8, 737.0], [32.9, 738.0], [33.0, 738.0], [33.1, 738.0], [33.2, 738.0], [33.3, 739.0], [33.4, 739.0], [33.5, 740.0], [33.6, 740.0], [33.7, 740.0], [33.8, 740.0], [33.9, 741.0], [34.0, 741.0], [34.1, 741.0], [34.2, 742.0], [34.3, 742.0], [34.4, 742.0], [34.5, 743.0], [34.6, 743.0], [34.7, 744.0], [34.8, 744.0], [34.9, 744.0], [35.0, 745.0], [35.1, 745.0], [35.2, 745.0], [35.3, 745.0], [35.4, 746.0], [35.5, 746.0], [35.6, 746.0], [35.7, 747.0], [35.8, 747.0], [35.9, 747.0], [36.0, 747.0], [36.1, 748.0], [36.2, 748.0], [36.3, 748.0], [36.4, 749.0], [36.5, 749.0], [36.6, 750.0], [36.7, 750.0], [36.8, 751.0], [36.9, 751.0], [37.0, 752.0], [37.1, 752.0], [37.2, 752.0], [37.3, 752.0], [37.4, 753.0], [37.5, 753.0], [37.6, 753.0], [37.7, 753.0], [37.8, 754.0], [37.9, 754.0], [38.0, 755.0], [38.1, 755.0], [38.2, 755.0], [38.3, 757.0], [38.4, 757.0], [38.5, 758.0], [38.6, 759.0], [38.7, 759.0], [38.8, 759.0], [38.9, 760.0], [39.0, 760.0], [39.1, 761.0], [39.2, 761.0], [39.3, 761.0], [39.4, 762.0], [39.5, 762.0], [39.6, 763.0], [39.7, 764.0], [39.8, 764.0], [39.9, 764.0], [40.0, 765.0], [40.1, 765.0], [40.2, 765.0], [40.3, 766.0], [40.4, 766.0], [40.5, 766.0], [40.6, 767.0], [40.7, 768.0], [40.8, 769.0], [40.9, 769.0], [41.0, 769.0], [41.1, 770.0], [41.2, 770.0], [41.3, 770.0], [41.4, 771.0], [41.5, 772.0], [41.6, 773.0], [41.7, 773.0], [41.8, 774.0], [41.9, 774.0], [42.0, 774.0], [42.1, 774.0], [42.2, 774.0], [42.3, 775.0], [42.4, 776.0], [42.5, 776.0], [42.6, 776.0], [42.7, 777.0], [42.8, 777.0], [42.9, 778.0], [43.0, 778.0], [43.1, 778.0], [43.2, 779.0], [43.3, 779.0], [43.4, 780.0], [43.5, 780.0], [43.6, 781.0], [43.7, 781.0], [43.8, 781.0], [43.9, 782.0], [44.0, 782.0], [44.1, 783.0], [44.2, 783.0], [44.3, 783.0], [44.4, 784.0], [44.5, 784.0], [44.6, 784.0], [44.7, 784.0], [44.8, 785.0], [44.9, 785.0], [45.0, 785.0], [45.1, 786.0], [45.2, 786.0], [45.3, 787.0], [45.4, 787.0], [45.5, 788.0], [45.6, 789.0], [45.7, 790.0], [45.8, 791.0], [45.9, 791.0], [46.0, 792.0], [46.1, 793.0], [46.2, 793.0], [46.3, 793.0], [46.4, 793.0], [46.5, 794.0], [46.6, 795.0], [46.7, 796.0], [46.8, 796.0], [46.9, 797.0], [47.0, 797.0], [47.1, 797.0], [47.2, 797.0], [47.3, 798.0], [47.4, 798.0], [47.5, 799.0], [47.6, 799.0], [47.7, 800.0], [47.8, 800.0], [47.9, 800.0], [48.0, 801.0], [48.1, 802.0], [48.2, 802.0], [48.3, 802.0], [48.4, 802.0], [48.5, 803.0], [48.6, 804.0], [48.7, 804.0], [48.8, 804.0], [48.9, 804.0], [49.0, 804.0], [49.1, 805.0], [49.2, 806.0], [49.3, 806.0], [49.4, 806.0], [49.5, 807.0], [49.6, 808.0], [49.7, 808.0], [49.8, 808.0], [49.9, 809.0], [50.0, 809.0], [50.1, 810.0], [50.2, 810.0], [50.3, 810.0], [50.4, 811.0], [50.5, 811.0], [50.6, 811.0], [50.7, 812.0], [50.8, 812.0], [50.9, 813.0], [51.0, 813.0], [51.1, 813.0], [51.2, 814.0], [51.3, 814.0], [51.4, 816.0], [51.5, 816.0], [51.6, 816.0], [51.7, 816.0], [51.8, 816.0], [51.9, 817.0], [52.0, 818.0], [52.1, 818.0], [52.2, 819.0], [52.3, 819.0], [52.4, 819.0], [52.5, 820.0], [52.6, 821.0], [52.7, 822.0], [52.8, 823.0], [52.9, 824.0], [53.0, 824.0], [53.1, 824.0], [53.2, 825.0], [53.3, 825.0], [53.4, 826.0], [53.5, 827.0], [53.6, 828.0], [53.7, 828.0], [53.8, 828.0], [53.9, 829.0], [54.0, 829.0], [54.1, 829.0], [54.2, 830.0], [54.3, 830.0], [54.4, 831.0], [54.5, 831.0], [54.6, 832.0], [54.7, 833.0], [54.8, 833.0], [54.9, 833.0], [55.0, 834.0], [55.1, 835.0], [55.2, 835.0], [55.3, 836.0], [55.4, 836.0], [55.5, 836.0], [55.6, 837.0], [55.7, 837.0], [55.8, 838.0], [55.9, 839.0], [56.0, 839.0], [56.1, 840.0], [56.2, 841.0], [56.3, 842.0], [56.4, 843.0], [56.5, 844.0], [56.6, 844.0], [56.7, 845.0], [56.8, 846.0], [56.9, 846.0], [57.0, 846.0], [57.1, 846.0], [57.2, 847.0], [57.3, 848.0], [57.4, 848.0], [57.5, 849.0], [57.6, 849.0], [57.7, 851.0], [57.8, 851.0], [57.9, 851.0], [58.0, 852.0], [58.1, 852.0], [58.2, 853.0], [58.3, 853.0], [58.4, 853.0], [58.5, 854.0], [58.6, 855.0], [58.7, 855.0], [58.8, 856.0], [58.9, 856.0], [59.0, 857.0], [59.1, 858.0], [59.2, 858.0], [59.3, 858.0], [59.4, 859.0], [59.5, 859.0], [59.6, 860.0], [59.7, 860.0], [59.8, 861.0], [59.9, 862.0], [60.0, 863.0], [60.1, 864.0], [60.2, 865.0], [60.3, 865.0], [60.4, 865.0], [60.5, 867.0], [60.6, 868.0], [60.7, 868.0], [60.8, 868.0], [60.9, 869.0], [61.0, 869.0], [61.1, 870.0], [61.2, 870.0], [61.3, 871.0], [61.4, 871.0], [61.5, 871.0], [61.6, 872.0], [61.7, 873.0], [61.8, 873.0], [61.9, 873.0], [62.0, 874.0], [62.1, 876.0], [62.2, 876.0], [62.3, 878.0], [62.4, 879.0], [62.5, 880.0], [62.6, 880.0], [62.7, 881.0], [62.8, 882.0], [62.9, 883.0], [63.0, 883.0], [63.1, 884.0], [63.2, 884.0], [63.3, 885.0], [63.4, 886.0], [63.5, 886.0], [63.6, 887.0], [63.7, 887.0], [63.8, 887.0], [63.9, 888.0], [64.0, 888.0], [64.1, 888.0], [64.2, 888.0], [64.3, 889.0], [64.4, 890.0], [64.5, 891.0], [64.6, 891.0], [64.7, 892.0], [64.8, 893.0], [64.9, 894.0], [65.0, 895.0], [65.1, 895.0], [65.2, 897.0], [65.3, 897.0], [65.4, 897.0], [65.5, 898.0], [65.6, 899.0], [65.7, 900.0], [65.8, 900.0], [65.9, 901.0], [66.0, 902.0], [66.1, 903.0], [66.2, 905.0], [66.3, 905.0], [66.4, 906.0], [66.5, 907.0], [66.6, 908.0], [66.7, 909.0], [66.8, 910.0], [66.9, 911.0], [67.0, 912.0], [67.1, 913.0], [67.2, 915.0], [67.3, 916.0], [67.4, 916.0], [67.5, 917.0], [67.6, 918.0], [67.7, 918.0], [67.8, 919.0], [67.9, 921.0], [68.0, 922.0], [68.1, 922.0], [68.2, 923.0], [68.3, 924.0], [68.4, 925.0], [68.5, 925.0], [68.6, 926.0], [68.7, 927.0], [68.8, 928.0], [68.9, 928.0], [69.0, 930.0], [69.1, 930.0], [69.2, 930.0], [69.3, 931.0], [69.4, 932.0], [69.5, 933.0], [69.6, 935.0], [69.7, 936.0], [69.8, 936.0], [69.9, 937.0], [70.0, 938.0], [70.1, 939.0], [70.2, 940.0], [70.3, 942.0], [70.4, 942.0], [70.5, 945.0], [70.6, 945.0], [70.7, 945.0], [70.8, 946.0], [70.9, 946.0], [71.0, 947.0], [71.1, 948.0], [71.2, 949.0], [71.3, 949.0], [71.4, 950.0], [71.5, 950.0], [71.6, 951.0], [71.7, 952.0], [71.8, 953.0], [71.9, 954.0], [72.0, 955.0], [72.1, 957.0], [72.2, 958.0], [72.3, 959.0], [72.4, 960.0], [72.5, 961.0], [72.6, 962.0], [72.7, 963.0], [72.8, 965.0], [72.9, 966.0], [73.0, 967.0], [73.1, 967.0], [73.2, 969.0], [73.3, 970.0], [73.4, 971.0], [73.5, 972.0], [73.6, 972.0], [73.7, 974.0], [73.8, 975.0], [73.9, 976.0], [74.0, 978.0], [74.1, 979.0], [74.2, 982.0], [74.3, 982.0], [74.4, 984.0], [74.5, 984.0], [74.6, 985.0], [74.7, 985.0], [74.8, 986.0], [74.9, 988.0], [75.0, 988.0], [75.1, 989.0], [75.2, 990.0], [75.3, 993.0], [75.4, 993.0], [75.5, 996.0], [75.6, 997.0], [75.7, 998.0], [75.8, 998.0], [75.9, 999.0], [76.0, 1000.0], [76.1, 1001.0], [76.2, 1003.0], [76.3, 1004.0], [76.4, 1006.0], [76.5, 1008.0], [76.6, 1008.0], [76.7, 1012.0], [76.8, 1014.0], [76.9, 1015.0], [77.0, 1016.0], [77.1, 1019.0], [77.2, 1020.0], [77.3, 1021.0], [77.4, 1023.0], [77.5, 1023.0], [77.6, 1027.0], [77.7, 1031.0], [77.8, 1032.0], [77.9, 1033.0], [78.0, 1034.0], [78.1, 1034.0], [78.2, 1036.0], [78.3, 1037.0], [78.4, 1039.0], [78.5, 1040.0], [78.6, 1041.0], [78.7, 1044.0], [78.8, 1046.0], [78.9, 1048.0], [79.0, 1051.0], [79.1, 1053.0], [79.2, 1057.0], [79.3, 1059.0], [79.4, 1061.0], [79.5, 1063.0], [79.6, 1066.0], [79.7, 1069.0], [79.8, 1077.0], [79.9, 1080.0], [80.0, 1083.0], [80.1, 1087.0], [80.2, 1088.0], [80.3, 1090.0], [80.4, 1091.0], [80.5, 1093.0], [80.6, 1096.0], [80.7, 1102.0], [80.8, 1102.0], [80.9, 1106.0], [81.0, 1107.0], [81.1, 1108.0], [81.2, 1109.0], [81.3, 1110.0], [81.4, 1112.0], [81.5, 1115.0], [81.6, 1116.0], [81.7, 1118.0], [81.8, 1118.0], [81.9, 1122.0], [82.0, 1125.0], [82.1, 1129.0], [82.2, 1130.0], [82.3, 1132.0], [82.4, 1138.0], [82.5, 1139.0], [82.6, 1142.0], [82.7, 1145.0], [82.8, 1150.0], [82.9, 1153.0], [83.0, 1157.0], [83.1, 1158.0], [83.2, 1159.0], [83.3, 1165.0], [83.4, 1168.0], [83.5, 1174.0], [83.6, 1183.0], [83.7, 1186.0], [83.8, 1192.0], [83.9, 1194.0], [84.0, 1198.0], [84.1, 1204.0], [84.2, 1205.0], [84.3, 1206.0], [84.4, 1210.0], [84.5, 1217.0], [84.6, 1220.0], [84.7, 1225.0], [84.8, 1228.0], [84.9, 1228.0], [85.0, 1231.0], [85.1, 1233.0], [85.2, 1234.0], [85.3, 1237.0], [85.4, 1242.0], [85.5, 1249.0], [85.6, 1251.0], [85.7, 1253.0], [85.8, 1254.0], [85.9, 1258.0], [86.0, 1265.0], [86.1, 1266.0], [86.2, 1267.0], [86.3, 1269.0], [86.4, 1273.0], [86.5, 1275.0], [86.6, 1281.0], [86.7, 1282.0], [86.8, 1288.0], [86.9, 1294.0], [87.0, 1296.0], [87.1, 1303.0], [87.2, 1306.0], [87.3, 1307.0], [87.4, 1312.0], [87.5, 1315.0], [87.6, 1316.0], [87.7, 1325.0], [87.8, 1330.0], [87.9, 1331.0], [88.0, 1333.0], [88.1, 1337.0], [88.2, 1339.0], [88.3, 1343.0], [88.4, 1346.0], [88.5, 1349.0], [88.6, 1351.0], [88.7, 1354.0], [88.8, 1357.0], [88.9, 1363.0], [89.0, 1367.0], [89.1, 1370.0], [89.2, 1375.0], [89.3, 1377.0], [89.4, 1379.0], [89.5, 1392.0], [89.6, 1404.0], [89.7, 1412.0], [89.8, 1423.0], [89.9, 1427.0], [90.0, 1429.0], [90.1, 1434.0], [90.2, 1435.0], [90.3, 1442.0], [90.4, 1448.0], [90.5, 1455.0], [90.6, 1458.0], [90.7, 1466.0], [90.8, 1475.0], [90.9, 1476.0], [91.0, 1483.0], [91.1, 1489.0], [91.2, 1494.0], [91.3, 1500.0], [91.4, 1502.0], [91.5, 1520.0], [91.6, 1529.0], [91.7, 1532.0], [91.8, 1542.0], [91.9, 1560.0], [92.0, 1565.0], [92.1, 1577.0], [92.2, 1589.0], [92.3, 1599.0], [92.4, 1603.0], [92.5, 1612.0], [92.6, 1632.0], [92.7, 1638.0], [92.8, 1643.0], [92.9, 1646.0], [93.0, 1667.0], [93.1, 1685.0], [93.2, 1700.0], [93.3, 1707.0], [93.4, 1722.0], [93.5, 1739.0], [93.6, 1757.0], [93.7, 1809.0], [93.8, 1819.0], [93.9, 1831.0], [94.0, 1838.0], [94.1, 1850.0], [94.2, 1878.0], [94.3, 1895.0], [94.4, 1900.0], [94.5, 1970.0], [94.6, 2000.0], [94.7, 2006.0], [94.8, 2027.0], [94.9, 2047.0], [95.0, 2053.0], [95.1, 2072.0], [95.2, 2081.0], [95.3, 2087.0], [95.4, 2117.0], [95.5, 2137.0], [95.6, 2158.0], [95.7, 2238.0], [95.8, 2288.0], [95.9, 2334.0], [96.0, 2364.0], [96.1, 2375.0], [96.2, 2394.0], [96.3, 2446.0], [96.4, 2476.0], [96.5, 2503.0], [96.6, 2552.0], [96.7, 2579.0], [96.8, 2599.0], [96.9, 2655.0], [97.0, 2678.0], [97.1, 2695.0], [97.2, 2747.0], [97.3, 2766.0], [97.4, 2818.0], [97.5, 2842.0], [97.6, 2867.0], [97.7, 2886.0], [97.8, 2992.0], [97.9, 3093.0], [98.0, 3238.0], [98.1, 3470.0], [98.2, 3603.0], [98.3, 3650.0], [98.4, 3833.0], [98.5, 3914.0], [98.6, 4035.0], [98.7, 4299.0], [98.8, 4846.0], [98.9, 5424.0], [99.0, 7545.0], [99.1, 8771.0], [99.2, 9090.0], [99.3, 11346.0], [99.4, 12504.0], [99.5, 13852.0], [99.6, 22407.0], [99.7, 24647.0], [99.8, 36033.0], [99.9, 67268.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 400.0, "maxY": 679.0, "series": [{"data": [[600.0, 501.0], [700.0, 679.0], [800.0, 480.0], [900.0, 273.0], [1000.0, 126.0], [1100.0, 90.0], [1200.0, 79.0], [1300.0, 68.0], [1400.0, 46.0], [1500.0, 29.0], [1600.0, 21.0], [1700.0, 14.0], [1800.0, 18.0], [1900.0, 6.0], [2000.0, 19.0], [2100.0, 8.0], [2300.0, 10.0], [2200.0, 6.0], [2400.0, 7.0], [2500.0, 9.0], [2600.0, 8.0], [2700.0, 6.0], [2800.0, 10.0], [2900.0, 3.0], [3000.0, 3.0], [3100.0, 1.0], [3200.0, 2.0], [3400.0, 2.0], [3500.0, 2.0], [3600.0, 3.0], [3700.0, 1.0], [3800.0, 4.0], [3900.0, 2.0], [4000.0, 1.0], [4100.0, 1.0], [4200.0, 2.0], [4600.0, 1.0], [4800.0, 1.0], [4700.0, 1.0], [5000.0, 1.0], [5400.0, 1.0], [5500.0, 1.0], [6900.0, 1.0], [7500.0, 1.0], [121900.0, 1.0], [7800.0, 1.0], [8600.0, 1.0], [8700.0, 1.0], [9000.0, 2.0], [9300.0, 1.0], [9700.0, 1.0], [11300.0, 1.0], [12100.0, 1.0], [12600.0, 1.0], [12500.0, 1.0], [12300.0, 1.0], [13800.0, 1.0], [19900.0, 1.0], [20700.0, 1.0], [22400.0, 1.0], [23000.0, 1.0], [24400.0, 1.0], [24600.0, 1.0], [31700.0, 1.0], [36000.0, 1.0], [38000.0, 1.0], [48200.0, 1.0], [195500.0, 1.0], [67200.0, 1.0], [400.0, 35.0], [500.0, 54.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 195500.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 36.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 2396.0, "series": [{"data": [[0.0, 36.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 2396.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 231.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 1.0, "minX": 1.78131522E12, "maxY": 50.0, "series": [{"data": [[1.78131522E12, 50.0], [1.7813154E12, 2.0], [1.78131546E12, 1.0], [1.78131528E12, 49.61224489795918], [1.78131534E12, 4.5]], "isOverall": false, "label": "setUp Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.78131546E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 505.0, "minX": 1.0, "maxY": 195536.0, "series": [{"data": [[33.0, 887.0], [32.0, 1045.0], [2.0, 121921.0], [35.0, 1665.0], [34.0, 827.0], [36.0, 742.0], [39.0, 866.3333333333334], [41.0, 1108.0], [40.0, 798.0], [43.0, 774.0], [45.0, 826.5], [47.0, 916.0], [46.0, 978.0], [3.0, 36033.0], [50.0, 1056.152522935778], [4.0, 24647.0], [5.0, 23006.0], [6.0, 67268.0], [7.0, 4761.0], [8.0, 48283.0], [9.0, 1494.0], [10.0, 3093.0], [11.0, 1737.0], [12.0, 738.0], [13.0, 783.0], [14.0, 683.0], [15.0, 666.0], [16.0, 1367.0], [1.0, 195536.0], [17.0, 778.0], [18.0, 770.0], [21.0, 819.3333333333334], [22.0, 505.0], [23.0, 785.0], [24.0, 19945.0], [27.0, 1020.3333333333334], [28.0, 681.0], [30.0, 1143.5], [31.0, 945.0]], "isOverall": false, "label": "HTTP Request", "isController": false}, {"data": [[49.54562523469769, 1254.935035674051]], "isOverall": false, "label": "HTTP Request-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 50.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 1.95, "minX": 1.78131522E12, "maxY": 1118762.85, "series": [{"data": [[1.78131522E12, 118988.8], [1.7813154E12, 464.03333333333336], [1.78131546E12, 464.0], [1.78131528E12, 1118762.85], [1.78131534E12, 2635.2833333333333]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.78131522E12, 499.2], [1.7813154E12, 1.95], [1.78131546E12, 1.95], [1.78131528E12, 4681.95], [1.78131534E12, 7.8]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.78131546E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 1069.9875052061598, "minX": 1.78131522E12, "maxY": 195536.0, "series": [{"data": [[1.78131522E12, 1189.2226562500016], [1.7813154E12, 121921.0], [1.78131546E12, 195536.0], [1.78131528E12, 1069.9875052061598], [1.78131534E12, 37738.5]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.78131546E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 843.1087047063737, "minX": 1.78131522E12, "maxY": 195299.0, "series": [{"data": [[1.78131522E12, 937.5429687499999], [1.7813154E12, 121812.0], [1.78131546E12, 195299.0], [1.78131528E12, 843.1087047063737], [1.78131534E12, 29846.75]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.78131546E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.78131522E12, "maxY": 226.00390625000009, "series": [{"data": [[1.78131522E12, 226.00390625000009], [1.7813154E12, 0.0], [1.78131546E12, 0.0], [1.78131528E12, 0.0], [1.78131534E12, 0.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.78131546E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 440.0, "minX": 1.78131522E12, "maxY": 195536.0, "series": [{"data": [[1.78131522E12, 4260.0], [1.7813154E12, 121921.0], [1.78131546E12, 195536.0], [1.78131528E12, 48283.0], [1.78131534E12, 67268.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.78131522E12, 442.0], [1.7813154E12, 121921.0], [1.78131546E12, 195536.0], [1.78131528E12, 440.0], [1.78131534E12, 23006.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.78131522E12, 2670.3], [1.7813154E12, 121921.0], [1.78131546E12, 195536.0], [1.78131528E12, 1337.8000000000002], [1.78131534E12, 67268.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.78131522E12, 4033.970000000002], [1.7813154E12, 121921.0], [1.78131546E12, 195536.0], [1.78131528E12, 5415.780000000008], [1.78131534E12, 67268.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.78131522E12, 724.0], [1.7813154E12, 121921.0], [1.78131546E12, 195536.0], [1.78131528E12, 812.0], [1.78131534E12, 30340.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.78131522E12, 3065.75], [1.7813154E12, 121921.0], [1.78131546E12, 195536.0], [1.78131528E12, 1663.4000000000015], [1.78131534E12, 67268.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.78131546E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 673.5, "minX": 1.0, "maxY": 51650.5, "series": [{"data": [[34.0, 1126.5], [37.0, 1032.0], [38.0, 879.0], [39.0, 871.0], [41.0, 874.5], [40.0, 899.5], [42.0, 808.5], [43.0, 814.0], [45.0, 783.0], [44.0, 851.0], [47.0, 799.0], [46.0, 847.5], [49.0, 792.0], [48.0, 762.0], [12.0, 1075.0], [50.0, 766.0], [51.0, 724.0], [52.0, 673.5], [53.0, 784.0], [55.0, 699.0], [59.0, 729.0], [58.0, 706.5], [1.0, 51650.5], [6.0, 1508.5]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 59.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 484.5, "minX": 1.0, "maxY": 45897.0, "series": [{"data": [[34.0, 868.0], [37.0, 856.0], [38.0, 738.5], [39.0, 698.0], [41.0, 753.5], [40.0, 750.5], [42.0, 692.0], [43.0, 696.0], [45.0, 689.0], [44.0, 687.5], [47.0, 630.0], [46.0, 714.0], [49.0, 698.0], [48.0, 653.0], [12.0, 626.5], [50.0, 658.5], [51.0, 605.0], [52.0, 484.5], [53.0, 646.0], [55.0, 537.0], [59.0, 600.0], [58.0, 611.5], [1.0, 45897.0], [6.0, 1303.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 59.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 5.1, "minX": 1.78131522E12, "maxY": 39.28333333333333, "series": [{"data": [[1.78131522E12, 5.1], [1.78131528E12, 39.28333333333333]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.78131528E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.78131522E12, "maxY": 40.016666666666666, "series": [{"data": [[1.78131522E12, 4.266666666666667], [1.7813154E12, 0.016666666666666666], [1.78131546E12, 0.016666666666666666], [1.78131528E12, 40.016666666666666], [1.78131534E12, 0.06666666666666667]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.78131546E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.78131522E12, "maxY": 40.016666666666666, "series": [{"data": [[1.78131522E12, 4.266666666666667], [1.7813154E12, 0.016666666666666666], [1.78131546E12, 0.016666666666666666], [1.78131528E12, 40.016666666666666], [1.78131534E12, 0.06666666666666667]], "isOverall": false, "label": "HTTP Request-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.78131546E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.78131522E12, "maxY": 40.016666666666666, "series": [{"data": [[1.78131522E12, 4.266666666666667], [1.7813154E12, 0.016666666666666666], [1.78131546E12, 0.016666666666666666], [1.78131528E12, 40.016666666666666], [1.78131534E12, 0.06666666666666667]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.78131546E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

