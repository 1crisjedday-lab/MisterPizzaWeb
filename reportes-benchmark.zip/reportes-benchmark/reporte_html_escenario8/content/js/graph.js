/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 415.0, "minX": 0.0, "maxY": 987136.0, "series": [{"data": [[0.0, 415.0], [0.1, 421.0], [0.2, 424.0], [0.3, 425.0], [0.4, 427.0], [0.5, 428.0], [0.6, 429.0], [0.7, 430.0], [0.8, 431.0], [0.9, 432.0], [1.0, 433.0], [1.1, 433.0], [1.2, 434.0], [1.3, 435.0], [1.4, 435.0], [1.5, 436.0], [1.6, 437.0], [1.7, 437.0], [1.8, 438.0], [1.9, 438.0], [2.0, 438.0], [2.1, 439.0], [2.2, 440.0], [2.3, 440.0], [2.4, 440.0], [2.5, 440.0], [2.6, 441.0], [2.7, 441.0], [2.8, 442.0], [2.9, 442.0], [3.0, 443.0], [3.1, 443.0], [3.2, 443.0], [3.3, 444.0], [3.4, 444.0], [3.5, 445.0], [3.6, 445.0], [3.7, 445.0], [3.8, 446.0], [3.9, 446.0], [4.0, 446.0], [4.1, 447.0], [4.2, 447.0], [4.3, 447.0], [4.4, 448.0], [4.5, 448.0], [4.6, 448.0], [4.7, 448.0], [4.8, 449.0], [4.9, 449.0], [5.0, 449.0], [5.1, 449.0], [5.2, 450.0], [5.3, 450.0], [5.4, 450.0], [5.5, 450.0], [5.6, 450.0], [5.7, 451.0], [5.8, 451.0], [5.9, 451.0], [6.0, 451.0], [6.1, 452.0], [6.2, 452.0], [6.3, 452.0], [6.4, 452.0], [6.5, 452.0], [6.6, 452.0], [6.7, 453.0], [6.8, 453.0], [6.9, 453.0], [7.0, 453.0], [7.1, 453.0], [7.2, 454.0], [7.3, 454.0], [7.4, 454.0], [7.5, 454.0], [7.6, 455.0], [7.7, 455.0], [7.8, 455.0], [7.9, 455.0], [8.0, 456.0], [8.1, 456.0], [8.2, 456.0], [8.3, 456.0], [8.4, 457.0], [8.5, 457.0], [8.6, 457.0], [8.7, 457.0], [8.8, 457.0], [8.9, 458.0], [9.0, 458.0], [9.1, 458.0], [9.2, 458.0], [9.3, 458.0], [9.4, 459.0], [9.5, 459.0], [9.6, 459.0], [9.7, 459.0], [9.8, 459.0], [9.9, 460.0], [10.0, 460.0], [10.1, 460.0], [10.2, 460.0], [10.3, 460.0], [10.4, 460.0], [10.5, 461.0], [10.6, 461.0], [10.7, 461.0], [10.8, 461.0], [10.9, 462.0], [11.0, 462.0], [11.1, 462.0], [11.2, 462.0], [11.3, 462.0], [11.4, 463.0], [11.5, 463.0], [11.6, 463.0], [11.7, 463.0], [11.8, 463.0], [11.9, 464.0], [12.0, 464.0], [12.1, 464.0], [12.2, 464.0], [12.3, 464.0], [12.4, 465.0], [12.5, 465.0], [12.6, 465.0], [12.7, 465.0], [12.8, 465.0], [12.9, 465.0], [13.0, 466.0], [13.1, 466.0], [13.2, 466.0], [13.3, 466.0], [13.4, 467.0], [13.5, 467.0], [13.6, 467.0], [13.7, 467.0], [13.8, 467.0], [13.9, 467.0], [14.0, 468.0], [14.1, 468.0], [14.2, 468.0], [14.3, 468.0], [14.4, 469.0], [14.5, 469.0], [14.6, 469.0], [14.7, 469.0], [14.8, 470.0], [14.9, 470.0], [15.0, 470.0], [15.1, 470.0], [15.2, 470.0], [15.3, 470.0], [15.4, 471.0], [15.5, 471.0], [15.6, 471.0], [15.7, 472.0], [15.8, 472.0], [15.9, 472.0], [16.0, 472.0], [16.1, 472.0], [16.2, 473.0], [16.3, 473.0], [16.4, 473.0], [16.5, 473.0], [16.6, 473.0], [16.7, 474.0], [16.8, 474.0], [16.9, 474.0], [17.0, 474.0], [17.1, 474.0], [17.2, 475.0], [17.3, 475.0], [17.4, 475.0], [17.5, 475.0], [17.6, 475.0], [17.7, 476.0], [17.8, 476.0], [17.9, 476.0], [18.0, 476.0], [18.1, 477.0], [18.2, 477.0], [18.3, 477.0], [18.4, 477.0], [18.5, 478.0], [18.6, 478.0], [18.7, 478.0], [18.8, 478.0], [18.9, 479.0], [19.0, 479.0], [19.1, 479.0], [19.2, 479.0], [19.3, 480.0], [19.4, 480.0], [19.5, 480.0], [19.6, 480.0], [19.7, 481.0], [19.8, 481.0], [19.9, 481.0], [20.0, 482.0], [20.1, 482.0], [20.2, 482.0], [20.3, 482.0], [20.4, 483.0], [20.5, 483.0], [20.6, 483.0], [20.7, 484.0], [20.8, 484.0], [20.9, 484.0], [21.0, 485.0], [21.1, 485.0], [21.2, 485.0], [21.3, 485.0], [21.4, 486.0], [21.5, 486.0], [21.6, 486.0], [21.7, 487.0], [21.8, 487.0], [21.9, 487.0], [22.0, 488.0], [22.1, 488.0], [22.2, 489.0], [22.3, 489.0], [22.4, 489.0], [22.5, 490.0], [22.6, 490.0], [22.7, 490.0], [22.8, 491.0], [22.9, 492.0], [23.0, 492.0], [23.1, 493.0], [23.2, 493.0], [23.3, 494.0], [23.4, 494.0], [23.5, 494.0], [23.6, 495.0], [23.7, 495.0], [23.8, 496.0], [23.9, 496.0], [24.0, 497.0], [24.1, 497.0], [24.2, 497.0], [24.3, 498.0], [24.4, 498.0], [24.5, 499.0], [24.6, 499.0], [24.7, 500.0], [24.8, 500.0], [24.9, 501.0], [25.0, 501.0], [25.1, 501.0], [25.2, 502.0], [25.3, 502.0], [25.4, 503.0], [25.5, 503.0], [25.6, 504.0], [25.7, 504.0], [25.8, 504.0], [25.9, 505.0], [26.0, 506.0], [26.1, 506.0], [26.2, 507.0], [26.3, 507.0], [26.4, 508.0], [26.5, 509.0], [26.6, 509.0], [26.7, 510.0], [26.8, 511.0], [26.9, 511.0], [27.0, 512.0], [27.1, 512.0], [27.2, 514.0], [27.3, 515.0], [27.4, 515.0], [27.5, 516.0], [27.6, 517.0], [27.7, 518.0], [27.8, 519.0], [27.9, 520.0], [28.0, 520.0], [28.1, 521.0], [28.2, 522.0], [28.3, 523.0], [28.4, 524.0], [28.5, 524.0], [28.6, 526.0], [28.7, 526.0], [28.8, 527.0], [28.9, 528.0], [29.0, 529.0], [29.1, 530.0], [29.2, 531.0], [29.3, 533.0], [29.4, 533.0], [29.5, 534.0], [29.6, 535.0], [29.7, 536.0], [29.8, 537.0], [29.9, 538.0], [30.0, 539.0], [30.1, 540.0], [30.2, 541.0], [30.3, 542.0], [30.4, 543.0], [30.5, 544.0], [30.6, 545.0], [30.7, 547.0], [30.8, 548.0], [30.9, 549.0], [31.0, 550.0], [31.1, 552.0], [31.2, 552.0], [31.3, 553.0], [31.4, 554.0], [31.5, 555.0], [31.6, 556.0], [31.7, 556.0], [31.8, 557.0], [31.9, 558.0], [32.0, 559.0], [32.1, 559.0], [32.2, 560.0], [32.3, 561.0], [32.4, 561.0], [32.5, 562.0], [32.6, 563.0], [32.7, 563.0], [32.8, 564.0], [32.9, 564.0], [33.0, 564.0], [33.1, 565.0], [33.2, 565.0], [33.3, 566.0], [33.4, 567.0], [33.5, 567.0], [33.6, 568.0], [33.7, 568.0], [33.8, 569.0], [33.9, 569.0], [34.0, 570.0], [34.1, 570.0], [34.2, 571.0], [34.3, 571.0], [34.4, 572.0], [34.5, 573.0], [34.6, 573.0], [34.7, 574.0], [34.8, 574.0], [34.9, 575.0], [35.0, 575.0], [35.1, 576.0], [35.2, 577.0], [35.3, 578.0], [35.4, 578.0], [35.5, 579.0], [35.6, 579.0], [35.7, 580.0], [35.8, 580.0], [35.9, 580.0], [36.0, 581.0], [36.1, 581.0], [36.2, 581.0], [36.3, 582.0], [36.4, 582.0], [36.5, 582.0], [36.6, 583.0], [36.7, 583.0], [36.8, 583.0], [36.9, 584.0], [37.0, 584.0], [37.1, 585.0], [37.2, 585.0], [37.3, 585.0], [37.4, 586.0], [37.5, 587.0], [37.6, 587.0], [37.7, 587.0], [37.8, 587.0], [37.9, 588.0], [38.0, 588.0], [38.1, 588.0], [38.2, 589.0], [38.3, 589.0], [38.4, 589.0], [38.5, 589.0], [38.6, 590.0], [38.7, 590.0], [38.8, 590.0], [38.9, 591.0], [39.0, 591.0], [39.1, 592.0], [39.2, 592.0], [39.3, 592.0], [39.4, 593.0], [39.5, 593.0], [39.6, 593.0], [39.7, 594.0], [39.8, 594.0], [39.9, 594.0], [40.0, 594.0], [40.1, 595.0], [40.2, 595.0], [40.3, 595.0], [40.4, 596.0], [40.5, 596.0], [40.6, 597.0], [40.7, 597.0], [40.8, 597.0], [40.9, 597.0], [41.0, 598.0], [41.1, 598.0], [41.2, 599.0], [41.3, 599.0], [41.4, 599.0], [41.5, 599.0], [41.6, 600.0], [41.7, 600.0], [41.8, 600.0], [41.9, 600.0], [42.0, 600.0], [42.1, 601.0], [42.2, 601.0], [42.3, 601.0], [42.4, 601.0], [42.5, 602.0], [42.6, 602.0], [42.7, 602.0], [42.8, 602.0], [42.9, 603.0], [43.0, 603.0], [43.1, 603.0], [43.2, 604.0], [43.3, 604.0], [43.4, 604.0], [43.5, 605.0], [43.6, 605.0], [43.7, 605.0], [43.8, 605.0], [43.9, 606.0], [44.0, 606.0], [44.1, 606.0], [44.2, 607.0], [44.3, 607.0], [44.4, 607.0], [44.5, 608.0], [44.6, 608.0], [44.7, 608.0], [44.8, 609.0], [44.9, 609.0], [45.0, 609.0], [45.1, 609.0], [45.2, 610.0], [45.3, 610.0], [45.4, 610.0], [45.5, 610.0], [45.6, 611.0], [45.7, 611.0], [45.8, 612.0], [45.9, 612.0], [46.0, 612.0], [46.1, 613.0], [46.2, 613.0], [46.3, 613.0], [46.4, 614.0], [46.5, 614.0], [46.6, 614.0], [46.7, 615.0], [46.8, 615.0], [46.9, 615.0], [47.0, 615.0], [47.1, 616.0], [47.2, 616.0], [47.3, 616.0], [47.4, 617.0], [47.5, 617.0], [47.6, 617.0], [47.7, 617.0], [47.8, 618.0], [47.9, 618.0], [48.0, 618.0], [48.1, 618.0], [48.2, 618.0], [48.3, 619.0], [48.4, 619.0], [48.5, 620.0], [48.6, 620.0], [48.7, 620.0], [48.8, 621.0], [48.9, 621.0], [49.0, 621.0], [49.1, 621.0], [49.2, 622.0], [49.3, 622.0], [49.4, 622.0], [49.5, 623.0], [49.6, 623.0], [49.7, 623.0], [49.8, 624.0], [49.9, 624.0], [50.0, 625.0], [50.1, 625.0], [50.2, 625.0], [50.3, 626.0], [50.4, 626.0], [50.5, 626.0], [50.6, 627.0], [50.7, 627.0], [50.8, 627.0], [50.9, 627.0], [51.0, 628.0], [51.1, 628.0], [51.2, 628.0], [51.3, 629.0], [51.4, 629.0], [51.5, 630.0], [51.6, 630.0], [51.7, 630.0], [51.8, 630.0], [51.9, 631.0], [52.0, 631.0], [52.1, 631.0], [52.2, 631.0], [52.3, 632.0], [52.4, 632.0], [52.5, 633.0], [52.6, 633.0], [52.7, 633.0], [52.8, 633.0], [52.9, 634.0], [53.0, 634.0], [53.1, 634.0], [53.2, 635.0], [53.3, 635.0], [53.4, 636.0], [53.5, 636.0], [53.6, 636.0], [53.7, 637.0], [53.8, 637.0], [53.9, 638.0], [54.0, 638.0], [54.1, 638.0], [54.2, 638.0], [54.3, 639.0], [54.4, 639.0], [54.5, 639.0], [54.6, 640.0], [54.7, 640.0], [54.8, 640.0], [54.9, 640.0], [55.0, 641.0], [55.1, 641.0], [55.2, 641.0], [55.3, 642.0], [55.4, 642.0], [55.5, 643.0], [55.6, 643.0], [55.7, 643.0], [55.8, 644.0], [55.9, 644.0], [56.0, 645.0], [56.1, 645.0], [56.2, 645.0], [56.3, 646.0], [56.4, 646.0], [56.5, 646.0], [56.6, 647.0], [56.7, 647.0], [56.8, 647.0], [56.9, 647.0], [57.0, 648.0], [57.1, 648.0], [57.2, 648.0], [57.3, 649.0], [57.4, 649.0], [57.5, 650.0], [57.6, 650.0], [57.7, 650.0], [57.8, 651.0], [57.9, 651.0], [58.0, 651.0], [58.1, 651.0], [58.2, 652.0], [58.3, 652.0], [58.4, 652.0], [58.5, 653.0], [58.6, 653.0], [58.7, 654.0], [58.8, 654.0], [58.9, 654.0], [59.0, 655.0], [59.1, 655.0], [59.2, 656.0], [59.3, 656.0], [59.4, 656.0], [59.5, 657.0], [59.6, 657.0], [59.7, 657.0], [59.8, 657.0], [59.9, 658.0], [60.0, 658.0], [60.1, 658.0], [60.2, 659.0], [60.3, 659.0], [60.4, 659.0], [60.5, 659.0], [60.6, 660.0], [60.7, 660.0], [60.8, 660.0], [60.9, 660.0], [61.0, 661.0], [61.1, 661.0], [61.2, 662.0], [61.3, 662.0], [61.4, 662.0], [61.5, 663.0], [61.6, 663.0], [61.7, 664.0], [61.8, 664.0], [61.9, 664.0], [62.0, 665.0], [62.1, 665.0], [62.2, 666.0], [62.3, 666.0], [62.4, 666.0], [62.5, 667.0], [62.6, 667.0], [62.7, 667.0], [62.8, 668.0], [62.9, 668.0], [63.0, 669.0], [63.1, 669.0], [63.2, 670.0], [63.3, 670.0], [63.4, 670.0], [63.5, 670.0], [63.6, 671.0], [63.7, 671.0], [63.8, 672.0], [63.9, 672.0], [64.0, 672.0], [64.1, 673.0], [64.2, 673.0], [64.3, 673.0], [64.4, 674.0], [64.5, 674.0], [64.6, 674.0], [64.7, 675.0], [64.8, 675.0], [64.9, 675.0], [65.0, 676.0], [65.1, 676.0], [65.2, 677.0], [65.3, 677.0], [65.4, 678.0], [65.5, 678.0], [65.6, 678.0], [65.7, 679.0], [65.8, 679.0], [65.9, 680.0], [66.0, 680.0], [66.1, 680.0], [66.2, 681.0], [66.3, 682.0], [66.4, 682.0], [66.5, 683.0], [66.6, 683.0], [66.7, 684.0], [66.8, 684.0], [66.9, 684.0], [67.0, 685.0], [67.1, 685.0], [67.2, 685.0], [67.3, 686.0], [67.4, 686.0], [67.5, 686.0], [67.6, 687.0], [67.7, 687.0], [67.8, 688.0], [67.9, 688.0], [68.0, 689.0], [68.1, 689.0], [68.2, 690.0], [68.3, 690.0], [68.4, 691.0], [68.5, 691.0], [68.6, 692.0], [68.7, 692.0], [68.8, 693.0], [68.9, 693.0], [69.0, 694.0], [69.1, 695.0], [69.2, 696.0], [69.3, 696.0], [69.4, 697.0], [69.5, 697.0], [69.6, 697.0], [69.7, 699.0], [69.8, 699.0], [69.9, 699.0], [70.0, 700.0], [70.1, 700.0], [70.2, 701.0], [70.3, 701.0], [70.4, 701.0], [70.5, 702.0], [70.6, 703.0], [70.7, 703.0], [70.8, 704.0], [70.9, 704.0], [71.0, 705.0], [71.1, 706.0], [71.2, 706.0], [71.3, 707.0], [71.4, 707.0], [71.5, 708.0], [71.6, 708.0], [71.7, 709.0], [71.8, 709.0], [71.9, 710.0], [72.0, 710.0], [72.1, 711.0], [72.2, 712.0], [72.3, 712.0], [72.4, 713.0], [72.5, 713.0], [72.6, 714.0], [72.7, 715.0], [72.8, 715.0], [72.9, 716.0], [73.0, 717.0], [73.1, 717.0], [73.2, 718.0], [73.3, 719.0], [73.4, 719.0], [73.5, 720.0], [73.6, 721.0], [73.7, 722.0], [73.8, 722.0], [73.9, 723.0], [74.0, 723.0], [74.1, 724.0], [74.2, 725.0], [74.3, 725.0], [74.4, 726.0], [74.5, 727.0], [74.6, 728.0], [74.7, 728.0], [74.8, 729.0], [74.9, 730.0], [75.0, 730.0], [75.1, 731.0], [75.2, 731.0], [75.3, 732.0], [75.4, 733.0], [75.5, 734.0], [75.6, 735.0], [75.7, 736.0], [75.8, 736.0], [75.9, 737.0], [76.0, 738.0], [76.1, 739.0], [76.2, 740.0], [76.3, 741.0], [76.4, 742.0], [76.5, 744.0], [76.6, 744.0], [76.7, 745.0], [76.8, 745.0], [76.9, 746.0], [77.0, 747.0], [77.1, 748.0], [77.2, 748.0], [77.3, 750.0], [77.4, 751.0], [77.5, 752.0], [77.6, 753.0], [77.7, 754.0], [77.8, 754.0], [77.9, 755.0], [78.0, 756.0], [78.1, 757.0], [78.2, 758.0], [78.3, 759.0], [78.4, 760.0], [78.5, 760.0], [78.6, 761.0], [78.7, 762.0], [78.8, 762.0], [78.9, 763.0], [79.0, 764.0], [79.1, 765.0], [79.2, 766.0], [79.3, 766.0], [79.4, 767.0], [79.5, 768.0], [79.6, 769.0], [79.7, 770.0], [79.8, 771.0], [79.9, 772.0], [80.0, 773.0], [80.1, 774.0], [80.2, 776.0], [80.3, 777.0], [80.4, 778.0], [80.5, 779.0], [80.6, 779.0], [80.7, 780.0], [80.8, 781.0], [80.9, 783.0], [81.0, 784.0], [81.1, 785.0], [81.2, 786.0], [81.3, 786.0], [81.4, 787.0], [81.5, 789.0], [81.6, 790.0], [81.7, 791.0], [81.8, 792.0], [81.9, 792.0], [82.0, 794.0], [82.1, 795.0], [82.2, 796.0], [82.3, 798.0], [82.4, 799.0], [82.5, 799.0], [82.6, 801.0], [82.7, 801.0], [82.8, 802.0], [82.9, 803.0], [83.0, 805.0], [83.1, 806.0], [83.2, 807.0], [83.3, 808.0], [83.4, 811.0], [83.5, 813.0], [83.6, 815.0], [83.7, 816.0], [83.8, 817.0], [83.9, 818.0], [84.0, 820.0], [84.1, 821.0], [84.2, 824.0], [84.3, 826.0], [84.4, 826.0], [84.5, 828.0], [84.6, 829.0], [84.7, 830.0], [84.8, 832.0], [84.9, 835.0], [85.0, 837.0], [85.1, 839.0], [85.2, 841.0], [85.3, 843.0], [85.4, 847.0], [85.5, 848.0], [85.6, 849.0], [85.7, 852.0], [85.8, 855.0], [85.9, 857.0], [86.0, 860.0], [86.1, 861.0], [86.2, 863.0], [86.3, 866.0], [86.4, 867.0], [86.5, 870.0], [86.6, 872.0], [86.7, 874.0], [86.8, 876.0], [86.9, 877.0], [87.0, 880.0], [87.1, 884.0], [87.2, 888.0], [87.3, 890.0], [87.4, 893.0], [87.5, 896.0], [87.6, 897.0], [87.7, 900.0], [87.8, 904.0], [87.9, 905.0], [88.0, 908.0], [88.1, 910.0], [88.2, 913.0], [88.3, 916.0], [88.4, 920.0], [88.5, 921.0], [88.6, 923.0], [88.7, 926.0], [88.8, 928.0], [88.9, 933.0], [89.0, 935.0], [89.1, 939.0], [89.2, 942.0], [89.3, 945.0], [89.4, 947.0], [89.5, 951.0], [89.6, 955.0], [89.7, 958.0], [89.8, 961.0], [89.9, 964.0], [90.0, 968.0], [90.1, 972.0], [90.2, 975.0], [90.3, 978.0], [90.4, 982.0], [90.5, 985.0], [90.6, 992.0], [90.7, 995.0], [90.8, 1002.0], [90.9, 1007.0], [91.0, 1018.0], [91.1, 1024.0], [91.2, 1029.0], [91.3, 1033.0], [91.4, 1040.0], [91.5, 1044.0], [91.6, 1049.0], [91.7, 1056.0], [91.8, 1062.0], [91.9, 1066.0], [92.0, 1072.0], [92.1, 1078.0], [92.2, 1082.0], [92.3, 1088.0], [92.4, 1095.0], [92.5, 1101.0], [92.6, 1110.0], [92.7, 1120.0], [92.8, 1127.0], [92.9, 1135.0], [93.0, 1142.0], [93.1, 1147.0], [93.2, 1155.0], [93.3, 1167.0], [93.4, 1172.0], [93.5, 1185.0], [93.6, 1190.0], [93.7, 1199.0], [93.8, 1204.0], [93.9, 1212.0], [94.0, 1220.0], [94.1, 1224.0], [94.2, 1233.0], [94.3, 1242.0], [94.4, 1246.0], [94.5, 1255.0], [94.6, 1263.0], [94.7, 1272.0], [94.8, 1293.0], [94.9, 1306.0], [95.0, 1318.0], [95.1, 1334.0], [95.2, 1348.0], [95.3, 1360.0], [95.4, 1380.0], [95.5, 1413.0], [95.6, 1431.0], [95.7, 1457.0], [95.8, 1473.0], [95.9, 1504.0], [96.0, 1542.0], [96.1, 1588.0], [96.2, 1615.0], [96.3, 1635.0], [96.4, 1680.0], [96.5, 1725.0], [96.6, 1749.0], [96.7, 1788.0], [96.8, 1845.0], [96.9, 1875.0], [97.0, 1917.0], [97.1, 1965.0], [97.2, 2053.0], [97.3, 2126.0], [97.4, 2221.0], [97.5, 2314.0], [97.6, 2388.0], [97.7, 2477.0], [97.8, 2563.0], [97.9, 2657.0], [98.0, 2697.0], [98.1, 2744.0], [98.2, 2911.0], [98.3, 2992.0], [98.4, 3243.0], [98.5, 3396.0], [98.6, 3553.0], [98.7, 3833.0], [98.8, 3991.0], [98.9, 4364.0], [99.0, 4759.0], [99.1, 5145.0], [99.2, 5552.0], [99.3, 6291.0], [99.4, 7656.0], [99.5, 9462.0], [99.6, 11812.0], [99.7, 16070.0], [99.8, 23050.0], [99.9, 31097.0], [100.0, 987136.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 400.0, "maxY": 2544.0, "series": [{"data": [[37300.0, 1.0], [46100.0, 1.0], [50100.0, 1.0], [400.0, 2210.0], [500.0, 1520.0], [600.0, 2544.0], [700.0, 1128.0], [800.0, 463.0], [900.0, 276.0], [1000.0, 156.0], [1100.0, 110.0], [1200.0, 102.0], [1300.0, 56.0], [1400.0, 39.0], [987100.0, 1.0], [1500.0, 23.0], [1600.0, 26.0], [1700.0, 24.0], [1800.0, 22.0], [1900.0, 15.0], [2000.0, 13.0], [2100.0, 11.0], [2300.0, 12.0], [2200.0, 8.0], [2400.0, 10.0], [2500.0, 9.0], [2600.0, 16.0], [2800.0, 5.0], [2700.0, 12.0], [2900.0, 10.0], [3000.0, 8.0], [3300.0, 5.0], [3200.0, 6.0], [3400.0, 6.0], [3500.0, 2.0], [3600.0, 4.0], [3700.0, 4.0], [3800.0, 4.0], [3900.0, 7.0], [4000.0, 2.0], [4200.0, 1.0], [4300.0, 3.0], [4100.0, 3.0], [4600.0, 4.0], [4400.0, 1.0], [4500.0, 1.0], [4700.0, 3.0], [4800.0, 1.0], [5000.0, 2.0], [4900.0, 3.0], [5100.0, 2.0], [5300.0, 2.0], [5200.0, 1.0], [5400.0, 4.0], [5500.0, 2.0], [5600.0, 1.0], [5700.0, 1.0], [5800.0, 1.0], [6000.0, 2.0], [6100.0, 1.0], [5900.0, 1.0], [6200.0, 2.0], [6300.0, 1.0], [6600.0, 1.0], [6400.0, 2.0], [6700.0, 1.0], [7000.0, 1.0], [7300.0, 1.0], [7400.0, 1.0], [7600.0, 2.0], [7700.0, 1.0], [8100.0, 2.0], [8400.0, 1.0], [8500.0, 2.0], [9000.0, 1.0], [9600.0, 3.0], [9400.0, 1.0], [10200.0, 1.0], [10300.0, 1.0], [10600.0, 1.0], [11000.0, 1.0], [11600.0, 1.0], [11800.0, 1.0], [11900.0, 2.0], [12600.0, 2.0], [12700.0, 1.0], [14300.0, 1.0], [14500.0, 1.0], [16000.0, 2.0], [16700.0, 1.0], [16800.0, 1.0], [18300.0, 1.0], [19000.0, 1.0], [20000.0, 2.0], [20700.0, 1.0], [21400.0, 1.0], [23000.0, 1.0], [24100.0, 1.0], [26600.0, 1.0], [29400.0, 1.0], [28900.0, 1.0], [30500.0, 1.0], [30400.0, 1.0], [30300.0, 1.0], [30800.0, 1.0], [31000.0, 1.0], [33800.0, 1.0], [34400.0, 1.0], [35800.0, 1.0], [38800.0, 1.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 987100.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 368.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 6374.0, "series": [{"data": [[0.0, 2230.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 6374.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 368.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 1.0, "minX": 1.78131768E12, "maxY": 25.0, "series": [{"data": [[1.7813178E12, 25.0], [1.78131798E12, 22.842519685039367], [1.78131792E12, 25.0], [1.78131888E12, 1.0], [1.78131774E12, 25.0], [1.78131768E12, 25.0], [1.78131786E12, 25.0]], "isOverall": false, "label": "setUp Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.78131888E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 445.0, "minX": 1.0, "maxY": 987136.0, "series": [{"data": [[8.0, 659.0], [2.0, 12717.0], [9.0, 772.0], [10.0, 896.0], [11.0, 782.0], [12.0, 567.0], [3.0, 8129.0], [13.0, 455.0], [14.0, 474.0], [15.0, 445.0], [4.0, 4969.0], [1.0, 987136.0], [17.0, 563.0], [18.0, 1029.0], [19.0, 669.0], [20.0, 466.0], [5.0, 2319.0], [21.0, 684.0], [23.0, 651.0], [24.0, 537.0], [6.0, 2099.0], [25.0, 828.7892266428247], [7.0, 1606.0]], "isOverall": false, "label": "HTTP Request", "isController": false}, {"data": [[24.966785555060177, 941.35577351761]], "isOverall": false, "label": "HTTP Request-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 25.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 1.95, "minX": 1.78131768E12, "maxY": 990690.4166666666, "series": [{"data": [[1.7813178E12, 769485.55], [1.78131798E12, 58927.51666666667], [1.78131792E12, 696659.0166666667], [1.78131888E12, 464.1666666666667], [1.78131774E12, 990690.4166666666], [1.78131768E12, 806509.8666666667], [1.78131786E12, 850486.2166666667]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.7813178E12, 3219.45], [1.78131798E12, 247.65], [1.78131792E12, 2915.25], [1.78131888E12, 1.95], [1.78131774E12, 4153.5], [1.78131768E12, 3387.15], [1.78131786E12, 3570.45]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.78131888E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 713.2821596244138, "minX": 1.78131768E12, "maxY": 987136.0, "series": [{"data": [[1.7813178E12, 905.5548152634761], [1.78131798E12, 888.6929133858268], [1.78131792E12, 994.5397993311035], [1.78131888E12, 987136.0], [1.78131774E12, 713.2821596244138], [1.78131768E12, 771.2682786413362], [1.78131786E12, 821.9290005461518]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.78131888E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 621.1042253521117, "minX": 1.78131768E12, "maxY": 987133.0, "series": [{"data": [[1.7813178E12, 748.8328285887342], [1.78131798E12, 804.9212598425195], [1.78131792E12, 857.1705685618738], [1.78131888E12, 987133.0], [1.78131774E12, 621.1042253521117], [1.78131768E12, 667.3926309729422], [1.78131786E12, 714.3156744948121]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.78131888E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.78131768E12, "maxY": 13.629821531375915, "series": [{"data": [[1.7813178E12, 4.988491823137494], [1.78131798E12, 0.0], [1.78131792E12, 6.7123745819398], [1.78131888E12, 0.0], [1.78131774E12, 4.206572769953044], [1.78131768E12, 13.629821531375915], [1.78131786E12, 4.971054068814863]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.78131888E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 415.0, "minX": 1.78131768E12, "maxY": 987136.0, "series": [{"data": [[1.7813178E12, 50120.0], [1.78131798E12, 12717.0], [1.78131792E12, 37318.0], [1.78131888E12, 987136.0], [1.78131774E12, 33860.0], [1.78131768E12, 38878.0], [1.78131786E12, 46105.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.7813178E12, 429.0], [1.78131798E12, 425.0], [1.78131792E12, 420.0], [1.78131888E12, 987136.0], [1.78131774E12, 417.0], [1.78131768E12, 415.0], [1.78131786E12, 428.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.7813178E12, 935.8], [1.78131798E12, 1166.6000000000001], [1.78131792E12, 1163.2000000000003], [1.78131888E12, 987136.0], [1.78131774E12, 785.8000000000002], [1.78131768E12, 904.0], [1.78131786E12, 1069.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.7813178E12, 6910.7200000000175], [1.78131798E12, 11432.359999999995], [1.78131792E12, 6798.7199999999675], [1.78131888E12, 987136.0], [1.78131774E12, 4190.96000000001], [1.78131768E12, 3207.139999999962], [1.78131786E12, 3823.44000000001]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.7813178E12, 664.0], [1.78131798E12, 567.0], [1.78131792E12, 655.0], [1.78131888E12, 987136.0], [1.78131774E12, 581.0], [1.78131768E12, 618.0], [1.78131786E12, 656.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.7813178E12, 1249.199999999999], [1.78131798E12, 1918.1999999999975], [1.78131792E12, 2572.800000000001], [1.78131888E12, 987136.0], [1.78131774E12, 1031.249999999999], [1.78131768E12, 1251.3999999999996], [1.78131786E12, 1356.799999999999]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.78131888E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 474.5, "minX": 1.0, "maxY": 10423.0, "series": [{"data": [[2.0, 1959.0], [32.0, 624.5], [33.0, 623.5], [34.0, 601.5], [35.0, 614.5], [36.0, 579.0], [37.0, 600.0], [39.0, 486.5], [38.0, 579.5], [40.0, 560.0], [41.0, 475.0], [43.0, 497.0], [42.0, 565.5], [45.0, 481.0], [44.0, 617.5], [46.0, 474.5], [49.0, 631.0], [50.0, 482.0], [4.0, 3022.5], [9.0, 832.0], [14.0, 638.0], [15.0, 2657.0], [16.0, 654.0], [1.0, 10423.0], [17.0, 860.0], [18.0, 770.0], [19.0, 683.5], [20.0, 704.5], [21.0, 715.5], [22.0, 690.0], [23.0, 704.0], [24.0, 668.5], [25.0, 681.0], [26.0, 652.0], [27.0, 666.0], [28.0, 652.0], [29.0, 653.0], [30.0, 634.0], [31.0, 609.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 50.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 454.0, "minX": 1.0, "maxY": 10372.0, "series": [{"data": [[2.0, 1936.5], [32.0, 535.5], [33.0, 531.0], [34.0, 516.0], [35.0, 520.5], [36.0, 495.0], [37.0, 510.0], [39.0, 466.0], [38.0, 496.5], [40.0, 486.0], [41.0, 464.0], [43.0, 472.0], [42.0, 501.0], [45.0, 467.5], [44.0, 512.0], [46.0, 454.0], [49.0, 487.0], [50.0, 461.0], [4.0, 2685.5], [9.0, 775.0], [14.0, 489.5], [15.0, 2464.0], [16.0, 561.0], [1.0, 10372.0], [17.0, 670.5], [18.0, 698.5], [19.0, 558.0], [20.0, 569.5], [21.0, 598.0], [22.0, 582.5], [23.0, 591.0], [24.0, 559.5], [25.0, 572.0], [26.0, 546.5], [27.0, 557.0], [28.0, 548.5], [29.0, 547.0], [30.0, 535.5], [31.0, 522.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 50.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 1.7166666666666666, "minX": 1.78131768E12, "maxY": 35.5, "series": [{"data": [[1.7813178E12, 27.516666666666666], [1.78131798E12, 1.7166666666666666], [1.78131792E12, 24.916666666666668], [1.78131774E12, 35.5], [1.78131768E12, 29.366666666666667], [1.78131786E12, 30.516666666666666]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.78131798E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.78131768E12, "maxY": 35.5, "series": [{"data": [[1.7813178E12, 27.516666666666666], [1.78131798E12, 2.1166666666666667], [1.78131792E12, 24.916666666666668], [1.78131888E12, 0.016666666666666666], [1.78131774E12, 35.5], [1.78131768E12, 28.95], [1.78131786E12, 30.516666666666666]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.78131888E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.78131768E12, "maxY": 35.5, "series": [{"data": [[1.7813178E12, 27.516666666666666], [1.78131798E12, 2.1166666666666667], [1.78131792E12, 24.916666666666668], [1.78131888E12, 0.016666666666666666], [1.78131774E12, 35.5], [1.78131768E12, 28.95], [1.78131786E12, 30.516666666666666]], "isOverall": false, "label": "HTTP Request-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.78131888E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.78131768E12, "maxY": 35.5, "series": [{"data": [[1.7813178E12, 27.516666666666666], [1.78131798E12, 2.1166666666666667], [1.78131792E12, 24.916666666666668], [1.78131888E12, 0.016666666666666666], [1.78131774E12, 35.5], [1.78131768E12, 28.95], [1.78131786E12, 30.516666666666666]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.78131888E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

