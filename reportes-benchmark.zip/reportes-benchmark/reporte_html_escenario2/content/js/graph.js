/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 437.0, "minX": 0.0, "maxY": 12148.0, "series": [{"data": [[0.0, 437.0], [0.1, 437.0], [0.2, 437.0], [0.3, 437.0], [0.4, 450.0], [0.5, 450.0], [0.6, 450.0], [0.7, 452.0], [0.8, 452.0], [0.9, 452.0], [1.0, 458.0], [1.1, 458.0], [1.2, 458.0], [1.3, 459.0], [1.4, 459.0], [1.5, 459.0], [1.6, 463.0], [1.7, 463.0], [1.8, 463.0], [1.9, 463.0], [2.0, 464.0], [2.1, 464.0], [2.2, 464.0], [2.3, 464.0], [2.4, 464.0], [2.5, 464.0], [2.6, 470.0], [2.7, 470.0], [2.8, 470.0], [2.9, 476.0], [3.0, 476.0], [3.1, 476.0], [3.2, 480.0], [3.3, 480.0], [3.4, 480.0], [3.5, 480.0], [3.6, 480.0], [3.7, 480.0], [3.8, 480.0], [3.9, 484.0], [4.0, 484.0], [4.1, 484.0], [4.2, 487.0], [4.3, 487.0], [4.4, 487.0], [4.5, 488.0], [4.6, 488.0], [4.7, 488.0], [4.8, 494.0], [4.9, 494.0], [5.0, 494.0], [5.1, 494.0], [5.2, 496.0], [5.3, 496.0], [5.4, 496.0], [5.5, 497.0], [5.6, 497.0], [5.7, 497.0], [5.8, 503.0], [5.9, 503.0], [6.0, 503.0], [6.1, 515.0], [6.2, 515.0], [6.3, 515.0], [6.4, 533.0], [6.5, 533.0], [6.6, 533.0], [6.7, 533.0], [6.8, 549.0], [6.9, 549.0], [7.0, 549.0], [7.1, 568.0], [7.2, 568.0], [7.3, 568.0], [7.4, 571.0], [7.5, 571.0], [7.6, 571.0], [7.7, 571.0], [7.8, 571.0], [7.9, 571.0], [8.0, 573.0], [8.1, 573.0], [8.2, 573.0], [8.3, 573.0], [8.4, 574.0], [8.5, 574.0], [8.6, 574.0], [8.7, 574.0], [8.8, 574.0], [8.9, 574.0], [9.0, 579.0], [9.1, 579.0], [9.2, 579.0], [9.3, 579.0], [9.4, 579.0], [9.5, 579.0], [9.6, 579.0], [9.7, 579.0], [9.8, 579.0], [9.9, 579.0], [10.0, 581.0], [10.1, 581.0], [10.2, 581.0], [10.3, 582.0], [10.4, 582.0], [10.5, 582.0], [10.6, 583.0], [10.7, 583.0], [10.8, 583.0], [10.9, 585.0], [11.0, 585.0], [11.1, 585.0], [11.2, 585.0], [11.3, 585.0], [11.4, 585.0], [11.5, 585.0], [11.6, 586.0], [11.7, 586.0], [11.8, 586.0], [11.9, 586.0], [12.0, 586.0], [12.1, 586.0], [12.2, 586.0], [12.3, 586.0], [12.4, 586.0], [12.5, 586.0], [12.6, 586.0], [12.7, 586.0], [12.8, 586.0], [12.9, 586.0], [13.0, 586.0], [13.1, 587.0], [13.2, 587.0], [13.3, 587.0], [13.4, 587.0], [13.5, 587.0], [13.6, 587.0], [13.7, 587.0], [13.8, 588.0], [13.9, 588.0], [14.0, 588.0], [14.1, 588.0], [14.2, 588.0], [14.3, 588.0], [14.4, 589.0], [14.5, 589.0], [14.6, 589.0], [14.7, 590.0], [14.8, 590.0], [14.9, 590.0], [15.0, 590.0], [15.1, 591.0], [15.2, 591.0], [15.3, 591.0], [15.4, 592.0], [15.5, 592.0], [15.6, 592.0], [15.7, 592.0], [15.8, 592.0], [15.9, 592.0], [16.0, 592.0], [16.1, 592.0], [16.2, 592.0], [16.3, 594.0], [16.4, 594.0], [16.5, 594.0], [16.6, 594.0], [16.7, 594.0], [16.8, 594.0], [16.9, 594.0], [17.0, 595.0], [17.1, 595.0], [17.2, 595.0], [17.3, 595.0], [17.4, 595.0], [17.5, 595.0], [17.6, 596.0], [17.7, 596.0], [17.8, 596.0], [17.9, 596.0], [18.0, 596.0], [18.1, 596.0], [18.2, 596.0], [18.3, 597.0], [18.4, 597.0], [18.5, 597.0], [18.6, 597.0], [18.7, 597.0], [18.8, 597.0], [18.9, 597.0], [19.0, 597.0], [19.1, 597.0], [19.2, 598.0], [19.3, 598.0], [19.4, 598.0], [19.5, 598.0], [19.6, 598.0], [19.7, 598.0], [19.8, 598.0], [19.9, 598.0], [20.0, 598.0], [20.1, 598.0], [20.2, 598.0], [20.3, 598.0], [20.4, 598.0], [20.5, 599.0], [20.6, 599.0], [20.7, 599.0], [20.8, 599.0], [20.9, 599.0], [21.0, 599.0], [21.1, 601.0], [21.2, 601.0], [21.3, 601.0], [21.4, 601.0], [21.5, 603.0], [21.6, 603.0], [21.7, 603.0], [21.8, 603.0], [21.9, 603.0], [22.0, 603.0], [22.1, 603.0], [22.2, 603.0], [22.3, 603.0], [22.4, 604.0], [22.5, 604.0], [22.6, 604.0], [22.7, 605.0], [22.8, 605.0], [22.9, 605.0], [23.0, 605.0], [23.1, 605.0], [23.2, 605.0], [23.3, 605.0], [23.4, 606.0], [23.5, 606.0], [23.6, 606.0], [23.7, 607.0], [23.8, 607.0], [23.9, 607.0], [24.0, 608.0], [24.1, 608.0], [24.2, 608.0], [24.3, 608.0], [24.4, 608.0], [24.5, 608.0], [24.6, 608.0], [24.7, 609.0], [24.8, 609.0], [24.9, 609.0], [25.0, 609.0], [25.1, 609.0], [25.2, 609.0], [25.3, 610.0], [25.4, 610.0], [25.5, 610.0], [25.6, 610.0], [25.7, 610.0], [25.8, 610.0], [25.9, 610.0], [26.0, 610.0], [26.1, 610.0], [26.2, 613.0], [26.3, 613.0], [26.4, 613.0], [26.5, 613.0], [26.6, 613.0], [26.7, 613.0], [26.8, 613.0], [26.9, 615.0], [27.0, 615.0], [27.1, 615.0], [27.2, 615.0], [27.3, 615.0], [27.4, 615.0], [27.5, 616.0], [27.6, 616.0], [27.7, 616.0], [27.8, 616.0], [27.9, 616.0], [28.0, 616.0], [28.1, 616.0], [28.2, 616.0], [28.3, 616.0], [28.4, 616.0], [28.5, 617.0], [28.6, 617.0], [28.7, 617.0], [28.8, 617.0], [28.9, 617.0], [29.0, 617.0], [29.1, 617.0], [29.2, 617.0], [29.3, 617.0], [29.4, 617.0], [29.5, 617.0], [29.6, 617.0], [29.7, 617.0], [29.8, 618.0], [29.9, 618.0], [30.0, 618.0], [30.1, 618.0], [30.2, 618.0], [30.3, 618.0], [30.4, 618.0], [30.5, 618.0], [30.6, 618.0], [30.7, 618.0], [30.8, 618.0], [30.9, 618.0], [31.0, 618.0], [31.1, 618.0], [31.2, 618.0], [31.3, 618.0], [31.4, 619.0], [31.5, 619.0], [31.6, 619.0], [31.7, 619.0], [31.8, 619.0], [31.9, 619.0], [32.0, 619.0], [32.1, 619.0], [32.2, 619.0], [32.3, 620.0], [32.4, 620.0], [32.5, 620.0], [32.6, 620.0], [32.7, 620.0], [32.8, 620.0], [32.9, 620.0], [33.0, 622.0], [33.1, 622.0], [33.2, 622.0], [33.3, 622.0], [33.4, 622.0], [33.5, 622.0], [33.6, 624.0], [33.7, 624.0], [33.8, 624.0], [33.9, 625.0], [34.0, 625.0], [34.1, 625.0], [34.2, 626.0], [34.3, 626.0], [34.4, 626.0], [34.5, 626.0], [34.6, 628.0], [34.7, 628.0], [34.8, 628.0], [34.9, 629.0], [35.0, 629.0], [35.1, 629.0], [35.2, 629.0], [35.3, 629.0], [35.4, 629.0], [35.5, 629.0], [35.6, 629.0], [35.7, 629.0], [35.8, 630.0], [35.9, 630.0], [36.0, 630.0], [36.1, 630.0], [36.2, 631.0], [36.3, 631.0], [36.4, 631.0], [36.5, 632.0], [36.6, 632.0], [36.7, 632.0], [36.8, 632.0], [36.9, 632.0], [37.0, 632.0], [37.1, 634.0], [37.2, 634.0], [37.3, 634.0], [37.4, 634.0], [37.5, 634.0], [37.6, 634.0], [37.7, 635.0], [37.8, 635.0], [37.9, 635.0], [38.0, 635.0], [38.1, 636.0], [38.2, 636.0], [38.3, 636.0], [38.4, 636.0], [38.5, 636.0], [38.6, 636.0], [38.7, 636.0], [38.8, 636.0], [38.9, 636.0], [39.0, 637.0], [39.1, 637.0], [39.2, 637.0], [39.3, 638.0], [39.4, 638.0], [39.5, 638.0], [39.6, 638.0], [39.7, 638.0], [39.8, 638.0], [39.9, 638.0], [40.0, 638.0], [40.1, 638.0], [40.2, 638.0], [40.3, 638.0], [40.4, 638.0], [40.5, 638.0], [40.6, 638.0], [40.7, 638.0], [40.8, 638.0], [40.9, 639.0], [41.0, 639.0], [41.1, 639.0], [41.2, 639.0], [41.3, 640.0], [41.4, 640.0], [41.5, 640.0], [41.6, 641.0], [41.7, 641.0], [41.8, 641.0], [41.9, 641.0], [42.0, 641.0], [42.1, 641.0], [42.2, 641.0], [42.3, 641.0], [42.4, 641.0], [42.5, 643.0], [42.6, 643.0], [42.7, 643.0], [42.8, 643.0], [42.9, 644.0], [43.0, 644.0], [43.1, 644.0], [43.2, 644.0], [43.3, 644.0], [43.4, 644.0], [43.5, 646.0], [43.6, 646.0], [43.7, 646.0], [43.8, 646.0], [43.9, 646.0], [44.0, 646.0], [44.1, 647.0], [44.2, 647.0], [44.3, 647.0], [44.4, 647.0], [44.5, 647.0], [44.6, 647.0], [44.7, 647.0], [44.8, 647.0], [44.9, 647.0], [45.0, 647.0], [45.1, 649.0], [45.2, 649.0], [45.3, 649.0], [45.4, 649.0], [45.5, 649.0], [45.6, 649.0], [45.7, 649.0], [45.8, 649.0], [45.9, 649.0], [46.0, 649.0], [46.1, 650.0], [46.2, 650.0], [46.3, 650.0], [46.4, 650.0], [46.5, 650.0], [46.6, 650.0], [46.7, 650.0], [46.8, 650.0], [46.9, 650.0], [47.0, 653.0], [47.1, 653.0], [47.2, 653.0], [47.3, 655.0], [47.4, 655.0], [47.5, 655.0], [47.6, 655.0], [47.7, 655.0], [47.8, 655.0], [47.9, 655.0], [48.0, 656.0], [48.1, 656.0], [48.2, 656.0], [48.3, 656.0], [48.4, 656.0], [48.5, 656.0], [48.6, 657.0], [48.7, 657.0], [48.8, 657.0], [48.9, 657.0], [49.0, 657.0], [49.1, 657.0], [49.2, 657.0], [49.3, 658.0], [49.4, 658.0], [49.5, 658.0], [49.6, 659.0], [49.7, 659.0], [49.8, 659.0], [49.9, 668.0], [50.0, 668.0], [50.1, 668.0], [50.2, 668.0], [50.3, 668.0], [50.4, 668.0], [50.5, 672.0], [50.6, 672.0], [50.7, 672.0], [50.8, 672.0], [50.9, 672.0], [51.0, 672.0], [51.1, 672.0], [51.2, 674.0], [51.3, 674.0], [51.4, 674.0], [51.5, 675.0], [51.6, 675.0], [51.7, 675.0], [51.8, 676.0], [51.9, 676.0], [52.0, 676.0], [52.1, 676.0], [52.2, 676.0], [52.3, 676.0], [52.4, 680.0], [52.5, 680.0], [52.6, 680.0], [52.7, 680.0], [52.8, 680.0], [52.9, 680.0], [53.0, 680.0], [53.1, 681.0], [53.2, 681.0], [53.3, 681.0], [53.4, 682.0], [53.5, 682.0], [53.6, 682.0], [53.7, 684.0], [53.8, 684.0], [53.9, 684.0], [54.0, 685.0], [54.1, 685.0], [54.2, 685.0], [54.3, 685.0], [54.4, 686.0], [54.5, 686.0], [54.6, 686.0], [54.7, 686.0], [54.8, 686.0], [54.9, 686.0], [55.0, 687.0], [55.1, 687.0], [55.2, 687.0], [55.3, 689.0], [55.4, 689.0], [55.5, 689.0], [55.6, 693.0], [55.7, 693.0], [55.8, 693.0], [55.9, 693.0], [56.0, 698.0], [56.1, 698.0], [56.2, 698.0], [56.3, 700.0], [56.4, 700.0], [56.5, 700.0], [56.6, 700.0], [56.7, 700.0], [56.8, 700.0], [56.9, 700.0], [57.0, 700.0], [57.1, 700.0], [57.2, 702.0], [57.3, 702.0], [57.4, 702.0], [57.5, 702.0], [57.6, 707.0], [57.7, 707.0], [57.8, 707.0], [57.9, 709.0], [58.0, 709.0], [58.1, 709.0], [58.2, 711.0], [58.3, 711.0], [58.4, 711.0], [58.5, 711.0], [58.6, 711.0], [58.7, 711.0], [58.8, 712.0], [58.9, 712.0], [59.0, 712.0], [59.1, 712.0], [59.2, 713.0], [59.3, 713.0], [59.4, 713.0], [59.5, 715.0], [59.6, 715.0], [59.7, 715.0], [59.8, 720.0], [59.9, 720.0], [60.0, 720.0], [60.1, 723.0], [60.2, 723.0], [60.3, 723.0], [60.4, 723.0], [60.5, 723.0], [60.6, 723.0], [60.7, 723.0], [60.8, 726.0], [60.9, 726.0], [61.0, 726.0], [61.1, 729.0], [61.2, 729.0], [61.3, 729.0], [61.4, 729.0], [61.5, 729.0], [61.6, 729.0], [61.7, 729.0], [61.8, 729.0], [61.9, 729.0], [62.0, 730.0], [62.1, 730.0], [62.2, 730.0], [62.3, 730.0], [62.4, 731.0], [62.5, 731.0], [62.6, 731.0], [62.7, 731.0], [62.8, 731.0], [62.9, 731.0], [63.0, 736.0], [63.1, 736.0], [63.2, 736.0], [63.3, 736.0], [63.4, 736.0], [63.5, 736.0], [63.6, 738.0], [63.7, 738.0], [63.8, 738.0], [63.9, 739.0], [64.0, 739.0], [64.1, 739.0], [64.2, 739.0], [64.3, 740.0], [64.4, 740.0], [64.5, 740.0], [64.6, 740.0], [64.7, 740.0], [64.8, 740.0], [64.9, 740.0], [65.0, 740.0], [65.1, 740.0], [65.2, 743.0], [65.3, 743.0], [65.4, 743.0], [65.5, 744.0], [65.6, 744.0], [65.7, 744.0], [65.8, 744.0], [65.9, 746.0], [66.0, 746.0], [66.1, 746.0], [66.2, 746.0], [66.3, 746.0], [66.4, 746.0], [66.5, 746.0], [66.6, 746.0], [66.7, 746.0], [66.8, 747.0], [66.9, 747.0], [67.0, 747.0], [67.1, 749.0], [67.2, 749.0], [67.3, 749.0], [67.4, 749.0], [67.5, 751.0], [67.6, 751.0], [67.7, 751.0], [67.8, 751.0], [67.9, 751.0], [68.0, 751.0], [68.1, 753.0], [68.2, 753.0], [68.3, 753.0], [68.4, 753.0], [68.5, 753.0], [68.6, 753.0], [68.7, 760.0], [68.8, 760.0], [68.9, 760.0], [69.0, 760.0], [69.1, 761.0], [69.2, 761.0], [69.3, 761.0], [69.4, 761.0], [69.5, 761.0], [69.6, 761.0], [69.7, 765.0], [69.8, 765.0], [69.9, 765.0], [70.0, 770.0], [70.1, 770.0], [70.2, 770.0], [70.3, 773.0], [70.4, 773.0], [70.5, 773.0], [70.6, 773.0], [70.7, 776.0], [70.8, 776.0], [70.9, 776.0], [71.0, 778.0], [71.1, 778.0], [71.2, 778.0], [71.3, 780.0], [71.4, 780.0], [71.5, 780.0], [71.6, 781.0], [71.7, 781.0], [71.8, 781.0], [71.9, 782.0], [72.0, 782.0], [72.1, 782.0], [72.2, 782.0], [72.3, 785.0], [72.4, 785.0], [72.5, 785.0], [72.6, 788.0], [72.7, 788.0], [72.8, 788.0], [72.9, 789.0], [73.0, 789.0], [73.1, 789.0], [73.2, 804.0], [73.3, 804.0], [73.4, 804.0], [73.5, 805.0], [73.6, 805.0], [73.7, 805.0], [73.8, 805.0], [73.9, 805.0], [74.0, 805.0], [74.1, 805.0], [74.2, 806.0], [74.3, 806.0], [74.4, 806.0], [74.5, 811.0], [74.6, 811.0], [74.7, 811.0], [74.8, 819.0], [74.9, 819.0], [75.0, 819.0], [75.1, 823.0], [75.2, 823.0], [75.3, 823.0], [75.4, 825.0], [75.5, 825.0], [75.6, 825.0], [75.7, 825.0], [75.8, 829.0], [75.9, 829.0], [76.0, 829.0], [76.1, 829.0], [76.2, 829.0], [76.3, 829.0], [76.4, 833.0], [76.5, 833.0], [76.6, 833.0], [76.7, 833.0], [76.8, 833.0], [76.9, 833.0], [77.0, 854.0], [77.1, 854.0], [77.2, 854.0], [77.3, 854.0], [77.4, 855.0], [77.5, 855.0], [77.6, 855.0], [77.7, 861.0], [77.8, 861.0], [77.9, 861.0], [78.0, 870.0], [78.1, 870.0], [78.2, 870.0], [78.3, 872.0], [78.4, 872.0], [78.5, 872.0], [78.6, 874.0], [78.7, 874.0], [78.8, 874.0], [78.9, 874.0], [79.0, 902.0], [79.1, 902.0], [79.2, 902.0], [79.3, 904.0], [79.4, 904.0], [79.5, 904.0], [79.6, 911.0], [79.7, 911.0], [79.8, 911.0], [79.9, 924.0], [80.0, 924.0], [80.1, 924.0], [80.2, 924.0], [80.3, 924.0], [80.4, 924.0], [80.5, 924.0], [80.6, 943.0], [80.7, 943.0], [80.8, 943.0], [80.9, 953.0], [81.0, 953.0], [81.1, 953.0], [81.2, 957.0], [81.3, 957.0], [81.4, 957.0], [81.5, 967.0], [81.6, 967.0], [81.7, 967.0], [81.8, 990.0], [81.9, 990.0], [82.0, 990.0], [82.1, 990.0], [82.2, 990.0], [82.3, 990.0], [82.4, 990.0], [82.5, 993.0], [82.6, 993.0], [82.7, 993.0], [82.8, 996.0], [82.9, 996.0], [83.0, 996.0], [83.1, 997.0], [83.2, 997.0], [83.3, 997.0], [83.4, 1000.0], [83.5, 1000.0], [83.6, 1000.0], [83.7, 1000.0], [83.8, 1002.0], [83.9, 1002.0], [84.0, 1002.0], [84.1, 1024.0], [84.2, 1024.0], [84.3, 1024.0], [84.4, 1037.0], [84.5, 1037.0], [84.6, 1037.0], [84.7, 1056.0], [84.8, 1056.0], [84.9, 1056.0], [85.0, 1057.0], [85.1, 1057.0], [85.2, 1057.0], [85.3, 1057.0], [85.4, 1060.0], [85.5, 1060.0], [85.6, 1060.0], [85.7, 1071.0], [85.8, 1071.0], [85.9, 1071.0], [86.0, 1094.0], [86.1, 1094.0], [86.2, 1094.0], [86.3, 1105.0], [86.4, 1105.0], [86.5, 1105.0], [86.6, 1122.0], [86.7, 1122.0], [86.8, 1122.0], [86.9, 1122.0], [87.0, 1130.0], [87.1, 1130.0], [87.2, 1130.0], [87.3, 1144.0], [87.4, 1144.0], [87.5, 1144.0], [87.6, 1145.0], [87.7, 1145.0], [87.8, 1145.0], [87.9, 1158.0], [88.0, 1158.0], [88.1, 1158.0], [88.2, 1162.0], [88.3, 1162.0], [88.4, 1162.0], [88.5, 1169.0], [88.6, 1169.0], [88.7, 1169.0], [88.8, 1169.0], [88.9, 1174.0], [89.0, 1174.0], [89.1, 1174.0], [89.2, 1176.0], [89.3, 1176.0], [89.4, 1176.0], [89.5, 1198.0], [89.6, 1198.0], [89.7, 1198.0], [89.8, 1209.0], [89.9, 1209.0], [90.0, 1209.0], [90.1, 1228.0], [90.2, 1228.0], [90.3, 1228.0], [90.4, 1228.0], [90.5, 1234.0], [90.6, 1234.0], [90.7, 1234.0], [90.8, 1235.0], [90.9, 1235.0], [91.0, 1235.0], [91.1, 1247.0], [91.2, 1247.0], [91.3, 1247.0], [91.4, 1260.0], [91.5, 1260.0], [91.6, 1260.0], [91.7, 1396.0], [91.8, 1396.0], [91.9, 1396.0], [92.0, 1396.0], [92.1, 1403.0], [92.2, 1403.0], [92.3, 1403.0], [92.4, 1506.0], [92.5, 1506.0], [92.6, 1506.0], [92.7, 1772.0], [92.8, 1772.0], [92.9, 1772.0], [93.0, 1961.0], [93.1, 1961.0], [93.2, 1961.0], [93.3, 2053.0], [93.4, 2053.0], [93.5, 2053.0], [93.6, 2053.0], [93.7, 2079.0], [93.8, 2079.0], [93.9, 2079.0], [94.0, 2109.0], [94.1, 2109.0], [94.2, 2109.0], [94.3, 2168.0], [94.4, 2168.0], [94.5, 2168.0], [94.6, 2386.0], [94.7, 2386.0], [94.8, 2386.0], [94.9, 2448.0], [95.0, 2448.0], [95.1, 2448.0], [95.2, 2448.0], [95.3, 2462.0], [95.4, 2462.0], [95.5, 2462.0], [95.6, 2462.0], [95.7, 2462.0], [95.8, 2462.0], [95.9, 2588.0], [96.0, 2588.0], [96.1, 2588.0], [96.2, 2638.0], [96.3, 2638.0], [96.4, 2638.0], [96.5, 2698.0], [96.6, 2698.0], [96.7, 2698.0], [96.8, 2698.0], [96.9, 3090.0], [97.0, 3090.0], [97.1, 3090.0], [97.2, 3172.0], [97.3, 3172.0], [97.4, 3172.0], [97.5, 3749.0], [97.6, 3749.0], [97.7, 3749.0], [97.8, 6152.0], [97.9, 6152.0], [98.0, 6152.0], [98.1, 6283.0], [98.2, 6283.0], [98.3, 6283.0], [98.4, 6283.0], [98.5, 7088.0], [98.6, 7088.0], [98.7, 7088.0], [98.8, 7625.0], [98.9, 7625.0], [99.0, 7625.0], [99.1, 10290.0], [99.2, 10290.0], [99.3, 10290.0], [99.4, 10367.0], [99.5, 10367.0], [99.6, 10367.0], [99.7, 12148.0], [99.8, 12148.0], [99.9, 12148.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 400.0, "maxY": 110.0, "series": [{"data": [[600.0, 110.0], [10200.0, 1.0], [10300.0, 1.0], [700.0, 53.0], [12100.0, 1.0], [800.0, 18.0], [900.0, 14.0], [1000.0, 9.0], [1100.0, 11.0], [1200.0, 6.0], [1300.0, 1.0], [1400.0, 1.0], [1500.0, 1.0], [1700.0, 1.0], [1900.0, 1.0], [2000.0, 2.0], [2100.0, 2.0], [2300.0, 1.0], [2400.0, 3.0], [2500.0, 1.0], [2600.0, 2.0], [3000.0, 1.0], [3100.0, 1.0], [3700.0, 1.0], [6100.0, 1.0], [6200.0, 1.0], [400.0, 18.0], [7000.0, 1.0], [7600.0, 1.0], [500.0, 48.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 12100.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 18.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 271.0, "series": [{"data": [[0.0, 18.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 271.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 24.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 2.0, "minX": 1.78131426E12, "maxY": 9.93225806451613, "series": [{"data": [[1.78131426E12, 9.93225806451613], [1.78131432E12, 2.0]], "isOverall": false, "label": "setUp Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.78131432E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 676.0, "minX": 1.0, "maxY": 12148.0, "series": [{"data": [[8.0, 726.0], [4.0, 6283.0], [2.0, 12148.0], [1.0, 7625.0], [9.0, 676.0], [10.0, 865.1973684210524], [5.0, 3749.0], [6.0, 730.0], [3.0, 10290.0], [7.0, 2698.0]], "isOverall": false, "label": "HTTP Request", "isController": false}, {"data": [[9.856230031948884, 983.849840255591]], "isOverall": false, "label": "HTTP Request-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 10.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 5.85, "minX": 1.78131426E12, "maxY": 144124.98333333334, "series": [{"data": [[1.78131426E12, 144124.98333333334], [1.78131432E12, 1586.2833333333333]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.78131426E12, 604.5], [1.78131432E12, 5.85]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.78131432E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 896.3935483870966, "minX": 1.78131426E12, "maxY": 10021.0, "series": [{"data": [[1.78131426E12, 896.3935483870966], [1.78131432E12, 10021.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.78131432E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 724.667741935484, "minX": 1.78131426E12, "maxY": 5009.666666666667, "series": [{"data": [[1.78131426E12, 724.667741935484], [1.78131432E12, 5009.666666666667]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.78131432E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.78131426E12, "maxY": 36.612903225806434, "series": [{"data": [[1.78131426E12, 36.612903225806434], [1.78131432E12, 0.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.78131432E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 437.0, "minX": 1.78131426E12, "maxY": 12148.0, "series": [{"data": [[1.78131426E12, 10367.0], [1.78131432E12, 12148.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.78131426E12, 437.0], [1.78131432E12, 7625.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.78131426E12, 1175.8000000000002], [1.78131432E12, 12148.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.78131426E12, 6268.589999999998], [1.78131432E12, 12148.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.78131426E12, 658.5], [1.78131432E12, 10290.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.78131426E12, 2135.5499999999993], [1.78131432E12, 12148.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.78131432E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 633.0, "minX": 1.0, "maxY": 10290.0, "series": [{"data": [[8.0, 733.5], [2.0, 5016.0], [9.0, 658.0], [10.0, 669.0], [11.0, 649.0], [12.0, 645.0], [13.0, 729.0], [14.0, 633.0], [15.0, 655.0], [16.0, 648.5], [4.0, 714.5], [1.0, 10290.0], [5.0, 726.0], [6.0, 733.0], [7.0, 1071.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 16.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 491.0, "minX": 1.0, "maxY": 4249.0, "series": [{"data": [[8.0, 537.5], [2.0, 4249.0], [9.0, 535.0], [10.0, 554.0], [11.0, 550.0], [12.0, 545.5], [13.0, 581.0], [14.0, 491.0], [15.0, 605.0], [16.0, 544.0], [4.0, 562.5], [1.0, 3384.0], [5.0, 576.0], [6.0, 539.0], [7.0, 862.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 16.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 5.216666666666667, "minX": 1.78131426E12, "maxY": 5.216666666666667, "series": [{"data": [[1.78131426E12, 5.216666666666667]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.78131426E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.05, "minX": 1.78131426E12, "maxY": 5.166666666666667, "series": [{"data": [[1.78131426E12, 5.166666666666667], [1.78131432E12, 0.05]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.78131432E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.05, "minX": 1.78131426E12, "maxY": 5.166666666666667, "series": [{"data": [[1.78131426E12, 5.166666666666667], [1.78131432E12, 0.05]], "isOverall": false, "label": "HTTP Request-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.78131432E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.05, "minX": 1.78131426E12, "maxY": 5.166666666666667, "series": [{"data": [[1.78131426E12, 5.166666666666667], [1.78131432E12, 0.05]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.78131432E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

